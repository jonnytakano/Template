﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Optimization;
using NLog;

namespace WebApp
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            //Inicianco Ioc
            UnityConfig.RegisterComponents();

            //Register Bundles
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            //Get the exception object.
            var ex = Server.GetLastError();
            LogManager.GetCurrentClassLogger().Error(ex, "Application_Error" + ex.Message);
        }

        protected void Application_End(object sender, EventArgs e)
        {
            UnityConfig.RemoveComponents();

        }
    }
}
