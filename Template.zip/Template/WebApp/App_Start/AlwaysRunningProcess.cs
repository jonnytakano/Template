﻿using NLog;
using NLog.Config;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp
{
    public class AlwaysRunningProcess : System.Web.Hosting.IProcessHostPreloadClient
    {
        public void Preload(string[] parameters)
        {
            //Carrega conf. do nlog
            LogManager.Configuration = new XmlLoggingConfiguration(AppDomain.CurrentDomain.BaseDirectory + "NLog.config");

            //Inicianco Ioc
            UnityConfig.RegisterComponents();

            //Inicia os Jobs que executam no sistema
            //HACK: desabilitando os Jobs da WebRole
            //JobScheduler.StartAllJobs();
        }
    }
}