﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace WebApp
{
    public class BundleConfig 
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            BundleTable.EnableOptimizations = false;
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                "~/Scripts/jquery-3.3.1.slim.min.js",
                "~/Scripts/jquery-3.2.1.min.js"));


            bundles.Add(new ScriptBundle("~/bundles/javascript").Include(
                "~/Scripts/popper.min.js",
                "~/Scripts/bootstrap.js",
                "~/Scripts/slide-toggle.js"));

            bundles.Add(new StyleBundle("~/bundles/css").Include(
                "~/css/bootstrap.css",
                "~/css/all.css",
                "~/css/custom.css"));
        }
    }
}