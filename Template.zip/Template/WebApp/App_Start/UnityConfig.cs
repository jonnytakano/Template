﻿using BLL.Amostragens;
using BLL.Amostragens.Interface;
using BLL.Arquivos;
using BLL.Arquivos.Interface;
using BLL.CancelamentoVendas;
using BLL.CancelamentoVendas.Interface;
using BLL.Clientes;
using BLL.Clientes.Interface;
using BLL.Cobrancas;
using BLL.Cobrancas.Interface;
using BLL.Contatos;
using BLL.Contatos.Interface;
using BLL.DetalhesParceiros;
using BLL.DetalhesParceiros.Interface;
using BLL.Distribuidoras;
using BLL.Distribuidoras.Interface;
using BLL.Enderecos;
using BLL.Enderecos.Interface;
using BLL.FaixaTarifaTotais.Interface;
using BLL.FaixaTarifaTotals;
using BLL.Indices;
using BLL.JobCCS;
using BLL.JobCCS.Interface;
using BLL.LogArquivo;
using BLL.LogArquivo.Interface;
using BLL.Login;
using BLL.Login.Interface;
using BLL.Parametros;
using BLL.Parametros.Interface;
using BLL.Parceiros;
using BLL.Parceiros.Interface;
using BLL.Parcelas;
using BLL.Parcelas.Interface;
using BLL.Perfis;
using BLL.Perfis.Interface;
using BLL.Pessoas;
using BLL.Pessoas.Interface;
using BLL.Produtos;
using BLL.Produtos.Interface;
using BLL.RamoAtividades;
using BLL.RamoAtividades.Interface;
using BLL.Relatorios;
using BLL.Relatorios.Interface;
using BLL.Tarifa_Distribuidora;
using BLL.Tarifa_Distribuidora.Interface;
using BLL.Telas;
using BLL.Telas.Interface;
using BLL.TipoContatos;
using BLL.TipoContatos.Interface;
using BLL.Usuarios;
using BLL.Usuarios.Interface;
using BLL.WebServiceHandle;
using BLL.WebServiceHandle.Interface;
using DAL.Amostragens;
using DAL.Amostragens.Interface;
using DAL.Arquivo;
using DAL.Arquivo.Interface;
using DAL.Arquivos;
using DAL.Arquivos.Interface;
using DAL.CancelamentoVendas;
using DAL.Clientes;
using DAL.Clientes.Interface;
using DAL.Cobrancas;
using DAL.Cobrancas.Interface;
using DAL.Contatos;
using DAL.Contatos.Interface;
using DAL.DetalhesParceiros;
using DAL.DetalhesParceiros.Interface;
using DAL.Distribuidoras;
using DAL.Distribuidoras.Interface;
using DAL.Enderecos.Interface;
using DAL.FaixaTarifaTotais;
using DAL.FaixaTarifaTotals.Interface;
using DAL.Indices.Interface;
using DAL.JobCCS;
using DAL.JobCCS.Interface;
using DAL.LogArquivo;
using DAL.LogArquivo.Interface;
using DAL.LogTransacoes;
using DAL.LogTransacoes.Interface;
using DAL.Parametros;
using DAL.Parametros.Interface;
using DAL.Parceiros;
using DAL.Parceiros.Interface;
using DAL.Parcelas;
using DAL.Parcelas.Interface;
using DAL.Perfis;
using DAL.Perfis.Interface;
using DAL.PerfisTela;
using DAL.PerfisTela.Interface;
using DAL.Pessoa;
using DAL.Pessoa.Interface;
using DAL.RamoAtividades;
using DAL.RamoAtividades.Interface;
using DAL.Tarifa_Distribuidora;
using DAL.Tarifa_Distribuidora.Interface;
using DAL.Telas;
using DAL.Telas.Interface;
using DAL.TipoContatos;
using DAL.TipoContatos.Interface;
using DAL.Usuarios;
using DAL.Usuarios.Interface;
using DAL.UsuariosParceiro;
using DAL.UsuariosParceiro.Interface;
using DAL.WebServices.Interface;
using Microsoft.Practices.ServiceLocation;
using Microsoft.Practices.Unity;

namespace WebApp
{
    public class UnityConfig
    {
        private static readonly IUnityContainer _container = new UnityContainer();

        /// <summary>
        /// Registra os componentes necessários ao sistema
        /// </summary>
        public static void RegisterComponents()
        {
            ServiceLocator.SetLocatorProvider(() => new UnityServiceLocator(_container));

            //Bussiness Layer
            _container.RegisterType<IPerfilBLO, PerfilBLO>();
            _container.RegisterType<IUsuarioBLO, UsuarioBLO>();
            _container.RegisterType<IUsuarioParceiroBLO, UsuarioParceiroBLO>();
            _container.RegisterType<IPerfilTelaBLO, PerfilTelaBLO>();
            _container.RegisterType<ITelaBLO, TelaBLO>();
            _container.RegisterType<ILoginBLO, LoginBLO>();
            _container.RegisterType<IClienteBLO, ClienteBLO>();
            _container.RegisterType<IPessoaFisicaBLO, PessoaFisicaBLO>();
            _container.RegisterType<IEnderecoBLO, EnderecoBLO>();
            _container.RegisterType<IPessoaJuridicaBLO, PessoaJuridicaBLO>();
            _container.RegisterType<IAnexoCobrancaBLO, AnexoCobrancaBLO>();
            _container.RegisterType<ICobrancaBLO, CobrancaBLO>();
            _container.RegisterType<IParcelaBLO, ParcelaBLO>();
            _container.RegisterType<IParametroBLO, ParametroBLO>();
            _container.RegisterType<ICancelamentoVendaBLO, CancelamentoVendaBLO>();
            _container.RegisterType<IAmostragemBLO, AmostragemBLO>();
            _container.RegisterType<ILeituraArquivoCobrancaBLO, LeituraArquivoCobrancaBLO>();
            _container.RegisterType<IArquivoImportacaoBLO, ArquivoImportacaoBLO>();
            _container.RegisterType<ILogArquivoBLO, LogArquivoBLO>();
            _container.RegisterType<IDistribuidoraBLO, DistribuidoraBLO>();
            _container.RegisterType<ITarifaDistribuidoraBLO, TarifaDistribuidoraBLO>();
            _container.RegisterType<IProdutosBLO, ProdutosBLO>();
            _container.RegisterType<IParceiroBLO, ParceiroBLO>();
            _container.RegisterType<IRamoAtividadeBLO, RamoAtividadeBLO>();
            _container.RegisterType<ITipoContatoBLO, TipoContatoBLO>();
            _container.RegisterType<IContatoBLO, ContatoBLO>();
            _container.RegisterType<IAnexoParceiroBLO, AnexoParceiroBLO>();
            _container.RegisterType<IIndiceBLO, IndiceBLO>();
            _container.RegisterType<IFaixaTarifaTotalBLO, FaixaTarifaTotalBLO>();
            _container.RegisterType<IDetalheParceiroBLO, DetalheParceiroBLO>();
            _container.RegisterType<IRelatorioBLO, RelatorioBLO>();
            _container.RegisterType<IJobCCSBLO, JobCCSBLO>();


            //Data Acess Layer
            _container.RegisterType<IPerfilDAO, PerfilDAO>();
            _container.RegisterType<IUsuarioDAO, UsuarioDAO>();
            _container.RegisterType<IUsuarioParceiroDAO, UsuarioParceiroDAO>();
            _container.RegisterType<IPerfilTelaDAO, PerfilTelaDAO>();
            _container.RegisterType<ITelaDAO, TelaDAO>();
            _container.RegisterType<IClienteDAO, ClienteDAO>();
            _container.RegisterType<IPessoaFisicaDAO, PessoaFisicaDAO>();
            _container.RegisterType<IPessoaJuridicaDAO, PessoaJuridicaDAO>();
            _container.RegisterType<IAnexoCobrancaDAO, AnexoCobrancaDAO>();
            _container.RegisterType<IEnderecoDAO, EnderecoDAO>();
            _container.RegisterType<ICobrancaDAO, CobrancaDAO>();
            _container.RegisterType<IDetalheLogDAO, DetalheLogDAO>();
            _container.RegisterType<IParcelaDAO, ParcelaDAO>();
            _container.RegisterType<IParametroDAO, ParametroDAO>();
            _container.RegisterType<ICancelamentoVendaDAO, CancelamentoVendaDAO>();
            _container.RegisterType<IAmostragemDAO, AmostragemDAO>();
            _container.RegisterType<IArquivoCobrancaDAO, ArquivoCobrancaDAO>();
            _container.RegisterType<IArquivoClienteDAO, ArquivoClienteDAO>();
            _container.RegisterType<ILogArquivoDAO, LogArquivoDAO>();
            _container.RegisterType<IArquivoImportacaoDAO, ArquivoImportacaoDAO>();
            _container.RegisterType<IRamoAtividadeDAO, RamoAtividadeDAO>();
            _container.RegisterType<ITipoContatoDAO, TipoContatoDAO>();
            _container.RegisterType<IContatoDAO, ContatoDAO>();
            _container.RegisterType<IParceiroDAO, ParceiroDAO>();
            _container.RegisterType<IAnexoParceiroDAO, AnexoParceiroDAO>();
            _container.RegisterType<IDistribuidoraDAO, DistribuidoraDAO>();
            _container.RegisterType<ITarifaDistribuidoraDAO, TarifaDistribuidoraDAO>();
            _container.RegisterType<IIndiceDAO, IndiceDAO>();
            _container.RegisterType<IDetalheParceiroDAO, DetalheParceiroDAO>();
            _container.RegisterType<IFaixaTarifaTotalDAO, FaixaTarifaTotalDAO>();
            _container.RegisterType<IJobCCSDAO, JobCCSDAO>();

            //WebService Layer
            _container.RegisterType<IWebServiceHandle, WebServiceHandle>();
            _container.RegisterType<IMI_GRAVAR_ATIVIDADE_SYNC_OUTService, MI_GRAVAR_ATIVIDADE_SYNC_OUTService>();
            _container.RegisterType<ISI_COBRANCA_TERCEIROS_SYNC_OUTArquivos, SI_COBRANCA_TERCEIROS_SYNC_OUTArquivos>();
            _container.RegisterType<ISI_COBRANCA_TERCEIROS_SYNC_OUTCobranca, SI_COBRANCA_TERCEIROS_SYNC_OUTCobranca>();
            _container.RegisterType<ISI_CONSULTA_CLIENTE_SYNC_OUTService, SI_CONSULTA_CLIENTE_SYNC_OUTService>();
            _container.RegisterType<ISI_CONSULTA_SERVICO_PN_SYNC_OUTService, SI_CONSULTA_SERVICO_PN_SYNC_OUTService>();
            _container.RegisterType<ISI_MOV_DIARIO_TERCEIROS_SYNC_OUTService, SI_MOV_DIARIO_TERCEIROS_SYNC_OUTService>();
            _container.RegisterType<ISI_REPASSE_SERVICO_TERCEIROS_SYNC_OUTService, SI_REPASSE_SERVICO_TERCEIROS_SYNC_OUTService>();
            _container.RegisterType<ISI_TARIFA_CPFL_TOTAL_OUTService, SI_TARIFA_CPFL_TOTAL_OUTService>();
            _container.RegisterType<ISI_TARIFA_DISTRIBUIDORA_SYNC_OUTService, SI_TARIFA_DISTRIBUIDORA_SYNC_OUTService>();
            _container.RegisterType<ISI_TARIFA_SERVICO_TERCEIROS_OUTService, SI_TARIFA_SERVICO_TERCEIROS_OUTService>();
        }

        public static void RemoveComponents()
        {
            _container.Dispose();
        }
    }
}