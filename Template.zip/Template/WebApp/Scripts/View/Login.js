﻿function Login() {
    if (!$('#formLogin').valid()) {
        if ($('#txtUsuario').val() == "") {
            //bootbox.alert("Hello world!", function () {
            //    Example.show("Hello world callback");
            //});
        }
       
    }
    else {
        $('#formLogin').submit();
    }
}