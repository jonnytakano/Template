﻿function CheckExpiredSession() {
    var now = new Date();
    if (now >= globalSessionExpirationTime)
        return true;
    else
        return false;
}

function RefreshExpirationDate() {
    globalSessionExpirationTime = new Date();
    globalSessionExpirationTime.setMinutes(globalSessionExpirationTime.getMinutes() + globalSessionTimeoutMinutes);
}