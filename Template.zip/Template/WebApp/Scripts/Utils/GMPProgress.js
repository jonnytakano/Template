﻿function ProgressDivShow() {
    $('#divProcessing').show();
    $('#processing-overlay').show();
}

function ProgressDivHide() {
    $('#divProcessing').hide();
    $('#processing-overlay').hide();
}