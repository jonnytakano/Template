﻿function GetQueryString() {
    var qs = (function (a) {
        if (a == "") return {};
        var b = {};
        for (var i = 0; i < a.length; ++i) {
            var p = a[i].split('=', 2);
            if (p.length == 1)
                b[p[0]] = "";
            else
                b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
        }
        return b;
    })(window.location.search.substr(1).split('&'));

    return qs;
}

function InicializaTooltip() {
    $('[data-toggle="tooltip"]').tooltip();
}

function InicializaMultiselect() {
    $.each($('.multiselect'), function () {
        ConfiguraMultiselect(this);
    });
}

function InicializaDraggable() {
    $('.draggable').draggable();
}

function ConfiguraMultiselect(element) {
    $(element).multiselect({
        includeSelectAllOption: false,
        nonSelectedText: 'Nenhum item selecionado',
        nSelectedText: 'selecionados',
        allSelectedText: 'Todos selecionados'
    });
}

function InicializaPopover() {

    $(function () {
        $('.popover-custom').each(function () {
            $(this).popover({
                html: true,
                container: 'body',
                content: CarregarPopover($(this).attr('data-popover-action'), ''),
                title: 'Título',
                trigger: "hover",
                placement: function (context, source) {
                    var position = $(source).position();

                    //if (position.top < 110) {
                    //    return "bottom";
                    //}

                    return "top";
                }
            });
        });
    });

}

function InicializaUnobtrusiveValidation(controle) {
    $.validator.unobtrusive.parse(controle);
    ValidationIgnore();
}

function ValidationIgnore() {
    if (($("[id^='form']")).length > 0) {
        for (var i = 0; i < ($("[id^='form']")).length; i++) {
            if ($(($("[id^='form']"))[i]).data("validator") != null) {
                $(($("[id^='form']"))[i]).data("validator").settings.ignore = ".data-val-ignore, :hidden:not(.hdnvalidate)"
            }
        }
    }
}

function ValidaEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}


function DatePickerRange(controleInicio, controleFinal, diasIntervalo) {

    DatePickerPadraoFuturo(controleInicio);
    DatePickerPadraoFuturo(controleFinal);

    controleInicio.on("dp.change", function (e) {

        var inicio = moment(controleInicio.val(), 'DD/MM/YYYY');
        var fim = moment(controleFinal.val(), 'DD/MM/YYYY');

        if (e.date != false) {

            var data = e.date.add(diasIntervalo, 'days').format("DD/MM/YYYY");

            if (controleFinal.val() == '' || inicio.diff(fim, 'days') >= 0) {
                controleFinal.val(data);
            }
        }
        else {
            controleFinal.val('');
        }
    });
    controleFinal.on("dp.change", function (e) {

        var inicio = moment(controleInicio.val(), 'DD/MM/YYYY');
        var fim = moment(controleFinal.val(), 'DD/MM/YYYY');

        if (e.date != false) {

            var data = e.date.add(diasIntervalo * -1, 'days').format("DD/MM/YYYY");

            if (controleInicio.val() == '' || fim.diff(inicio, 'days') <= 0) {
                controleInicio.val(data);
            }
        }
        else {
            controleInicio.val('');
        }
    });
}

function DatePickerPadrao(controle) {
    controle.datetimepicker(
    {
        locale: 'pt-BR',
        format: 'DD/MM/YYYY',
        minDate: '-1999/01/01',
        maxDate: 'now',
    });
}

function DatePickerPadraoFuturo(controle) {
    controle.datetimepicker(
    {
        locale: 'pt-BR',
        format: 'DD/MM/YYYY',
        minDate: '-1999/01/01'
    });
}

function DatePickerSoFuturo(controle) {
    controle.datetimepicker(
        {
            locale: 'pt-BR',
            format: 'DD/MM/YYYY',
            minDate: 'now',
        });
}

function DatePickerFiltroProgramacaoEsquerda(controle) {
    controle.datetimepicker(
    {
        locale: 'pt-BR',
        format: 'DD/MM/YYYY',
        minDate: '-1999/01/01',
        widgetPositioning: {
            vertical: 'top',
            horizontal: 'right'
        }
    });
}

function HandleBeforeSend(xhr, titulo, mensagemSessaoExpirada) {
    if (CheckExpiredSession()) {
        ExibeMensagemErro(titulo, mensagemSessaoExpirada);

        if (xhr != null)
            xhr.abort();

        setTimeout(function () { location.reload(true); }, 6500);
    }
}

function HabilitaScrollLinks() {
    $('a[href^="#"]').on('click', function (event) {
        var target = $(this).attr('href');
        if (target !== '#') {
            if (target.length) {
                event.preventDefault();
                $('html, body').stop().animate({
                    scrollTop: $(target).offset().top - 90
                }, 500);
            }
        }
    });
}

function validateTimeHH(timeValue) {
    if (timeValue == "" || timeValue.indexOf(":") < 0) {
        return false;
    }
    else {
        var sHours = timeValue.split(':')[0];
        var sMinutes = timeValue.split(':')[1];
        var sSeconds = timeValue.split(':')[2];

        if (sHours == "" || isNaN(sHours) || parseInt(sHours) > 23) {
            return false;
        }
        if (sMinutes == "" || isNaN(sMinutes) || parseInt(sMinutes) > 59) {
            return false;
        }
        if (sSeconds == "" || isNaN(sSeconds) || parseInt(sSeconds) > 59) {
            return false;
        }
    }
    return true;
}

var DataTableslangPTBR = {
    "sEmptyTable": "Nenhum registro encontrado",
    "sInfo": "Mostrando de _START_ até _END_ de _TOTAL_ registros",
    "sInfoEmpty": "Mostrando 0 até 0 de 0 registros",
    "sInfoFiltered": "(Filtrados de _MAX_ registros)",
    "sInfoPostFix": "",
    "sInfoThousands": ".",
    "sLengthMenu": "_MENU_ resultados por página",
    "sLoadingRecords": "Carregando...",
    "sProcessing": "Processando...",
    "sZeroRecords": "Nenhum registro encontrado",
    "sSearch": "Pesquisar",
    "oPaginate": {
        "sNext": "Próximo",
        "sPrevious": "Anterior",
        "sFirst": "Primeiro",
        "sLast": "Último"
    },
    "oAria": {
        "sSortAscending": ": Ordenar colunas de forma ascendente",
        "sSortDescending": ": Ordenar colunas de forma descendente"
    }
}

function DataTablesPadrao(controle, cabecalho) {

    if ($.fn.DataTable.isDataTable(controle)) {
        $(controle).empty();
    }

    var dataTable = $(controle).dataTable({
        language: DataTableslangPTBR,
        searching: false,
        pageLength: 5,
        lengthChange: false
    });

    //So coloca cabecalho se o parametro foi informado
    if (cabecalho != undefined) {
        if ($(controle).find('caption').length == 0) {
            $('<caption/>').html("<label class='control-label'>" + cabecalho + "</label>").appendTo(controle);
        }
    }

    return dataTable;
}

function DataTablesPadraoFooter(controle, colunas, colunasDef, cabecalho) {
    if ($.fn.DataTable.isDataTable(controle)) {
        $(controle).empty();
    }

    var dataTable = $(controle).dataTable({
        destroy: true,
        language: DataTableslangPTBR,
        searching: false,
        pageLength: 5,
        lengthChange: false,
        paging: true,
        ordering: false,
        columns: colunas,
        columnDefs: colunasDef,
        autoWidth: false
    });

    //So coloca cabecalho se o parametro foi informado
    if (cabecalho != undefined) {
        if ($(controle).find('caption').length == 0) {
            $('<caption/>').html("<label class='control-label'>" + cabecalho + "</label>").appendTo(controle);
        }
    }

    return dataTable;
}

// renomeado de DataTablesPadraoNovo
function DataTablesAjaxPaginacao(controle, colunas, dados, colunasDef, pagesLength, cabecalho) {

    if ($.fn.DataTable.isDataTable(controle)) {
        $(controle).empty();
    }

    if (pagesLength == "")
        pagesLength = 15;

    var dataTable = $(controle).dataTable({
        destroy: true,
        language: DataTableslangPTBR,
        searching: false,
        pageLength: pagesLength,
        lengthChange: false,
        paging: true,
        ordering: true,
        data: dados,
        columns: colunas,
        columnDefs: colunasDef,
        autoWidth: false
    });

    //So coloca cabecalho se o parametro foi informado
    if (cabecalho != undefined) {
        if ($(controle).find('caption').length == 0) {
            $('<caption/>').html("<label class='control-label'>" + cabecalho + "</label>").appendTo(controle);
        }
    }

    return dataTable;
}

function DataTablesAjaxPaginacaoPertubacao(controle, colunas, dados, colunasDef, pagesLength, cabecalho) {
    if ($.fn.DataTable.isDataTable(controle)) $(controle).empty();
    if (pagesLength == "") pagesLength = 15;
    $.fn.dataTable.moment('dd/MM/yyyy HH:mm:ss');

    var dataTable = $(controle).dataTable({
        destroy: true,
        language: DataTableslangPTBR,
        searching: false,
        pageLength: pagesLength,
        lengthChange: false,
        paging: true,
        ordering: true,
        data: dados,
        columns: colunas,
        columnDefs: colunasDef,
        order: [[1, "desc"]],
        autoWidth: false,
        deferRender: true
    });

    //So coloca cabecalho se o parametro foi informado
    if (cabecalho != undefined) {
        if ($(controle).find('caption').length == 0) {
            $('<caption/>').html("<label class='control-label'>" + cabecalho + "</label>").appendTo(controle);
        }
    }

    return dataTable;
}

// Com paginação e sem Ordenação
function DataTablesAjaxPaginacaoNoOrdering(controle, colunas, dados, colunasDef, pagesLength, cabecalho) {
    if ($.fn.DataTable.isDataTable(controle)) {
        $(controle).empty();
    }

    if (pagesLength == "")
        pagesLength = 15;

    var dataTable = $(controle).dataTable({
        destroy: true,
        language: DataTableslangPTBR,
        searching: false,
        pageLength: pagesLength,
        lengthChange: false,
        paging: true,
        ordering: false,
        data: dados,
        columns: colunas,
        columnDefs: colunasDef,
        autoWidth: false
    });

    //So coloca cabecalho se o parametro foi informado
    if (cabecalho != undefined) {
        if ($(controle).find('caption').length == 0) {
            $('<caption/>').html("<label class='control-label'>" + cabecalho + "</label>").appendTo(controle);
        }
    }

    return dataTable;
}

function DataTablesAjaxSemPaginacao(controle, colunas, dados, colunasDef, cabecalho) {
    if ($.fn.DataTable.isDataTable(controle)) {
        $(controle).empty();
    }

    var dataTable = $(controle).dataTable({
        destroy: true,
        language: DataTableslangPTBR,
        searching: false,
        pageLength: 0,
        lengthChange: false,
        paging: false,
        ordering: true,
        data: dados,
        columns: colunas,
        columnDefs: colunasDef,
        autoWidth: false,
        sDom: 'rt'
    });

    //So coloca cabecalho se o parametro foi informado
    if (cabecalho != undefined) {
        if ($(controle).find('caption').length == 0) {
            $('<caption/>').html("<label class='control-label'>" + cabecalho + "</label>").appendTo(controle);
        }
    }

    return dataTable;
}

function DataTablesAjaxSemPaginacaoMonitorPertubacao(controle, colunas, dados, colunasDef, cabecalho) {
    if ($.fn.DataTable.isDataTable(controle)) {
        $(controle).empty();
    }

    var dataTable = $(controle).dataTable({
        destroy: true,
        language: DataTableslangPTBR,
        searching: false,
        pageLength: 0,
        lengthChange: false,
        paging: false,
        ordering: true,
        data: dados,
        columns: colunas,
        columnDefs: colunasDef,
        order: [[1, "desc"]],
        autoWidth: false,
        sDom: 'rt'
    });

    //So coloca cabecalho se o parametro foi informado
    if (cabecalho != undefined) {
        if ($(controle).find('caption').length == 0) {
            $('<caption/>').html("<label class='control-label'>" + cabecalho + "</label>").appendTo(controle);
        }
    }

    return dataTable;
}

/*jQuery.extend(jQuery.fn.dataTableExt.oSort, {
    "date-euro-pre": function (a) {
        if ($.trim(a) != '') {
            var frDatea = $.trim(a).split(' ');
            var frTimea = frDatea[1].split(':');
            var frDatea2 = frDatea[0].split('/');

            var x = (frDatea2[2] + frDatea2[1] + frDatea2[0] + frTimea[0] + frTimea[1] + frTimea[2]) * 1;

        } else {
            var x = 10000000000000; // = l'an 1000 ...
        }
        return x;
    },
    "date-euro-asc": function (a, b) {
        return a - b;
    },

    "date-euro-desc": function (a, b) {
        return b - a;
    }
});*/

function DataTablesAjaxScroll(controle, colunas, dados, colunasDef, cabecalho) {
    if ($.fn.DataTable.isDataTable(controle)) {
        $(controle).empty();
    }

    var dataTable = $(controle).dataTable({
        destroy: true,
        language: DataTableslangPTBR,
        searching: false,
        scrollCollapse: true,
        lengthChange: false,
        paging: false,
        ordering: false,
        data: dados,
        columns: colunas,
        columnDefs: colunasDef,
        autoWidth: false
    });

    //So coloca cabecalho se o parametro foi informado
    if (cabecalho != undefined) {
        if ($(controle).find('caption').length == 0) {
            $('<caption/>').html("<label class='control-label'>" + cabecalho + "</label>").appendTo(controle);
        }
    }

    return dataTable;
}
//Data table sem Scroll e sem Paginação
function DataTablesAjax(controle, colunas, dados, colunasDef, cabecalho) {
    if ($.fn.DataTable.isDataTable(controle)) {
        $(controle).empty();
    }

    var dataTable = $(controle).dataTable({
        destroy: true,
        language: DataTableslangPTBR,
        searching: false,
        scrollCollapse: false,
        lengthChange: false,
        paging: false,
        ordering: false,
        data: dados,
        columns: colunas,
        columnDefs: colunasDef,
        autoWidth: false,
        info: false,
        allowPaging: false
    });

    //So coloca cabecalho se o parametro foi informado
    if (cabecalho != undefined) {
        if ($(controle).find('caption').length == 0) {
            $('<caption/>').html("<label class='control-label'>" + cabecalho + "</label>").appendTo(controle);
        }
    }

    return dataTable;
}

function modalPopUp(urlAction, param) {
    $.ajax({
        url: urlAction,
        data: param,
        type: 'POST',
        success: function (content) {
            $('#modalConteudo').html(content);
            $('#modalPartialView').modal('show');
        }
    });
}

function modalClose() {
    $('#modalPartialView').modal('hide');
}

function LoadDivJqueryAjaxGet(url, data, divControl) {
    $.ajax({
        url: url,
        data: data,
        type: 'GET',
        success: function (content) {
            divControl.html(content);
        }
    });
}

function LoadDivJqueryAjaxPost(url, data, divControl) {
    $.ajax({

        url: url,
        data: data,
        type: 'POST',
        success: function (content) {
            divControl.html(content);
        }
    });
}

function LoadDivJqueryAjaxPostAsync(url, data, divControl) {
    $.ajax({
        url: url,
        data: data,
        type: 'POST',
        success: function (content) {
            divControl.html(content);
        }
    });
}

function Mascaras() {

    $('.defaultMoneyMask').mask('000t000t000d00'.replace(/t/g, '.').replace('d', ','), { reverse: true });
    $('.reducedMoneyMask').mask('00.000,00', { reverse: true });
    $('.MiddleMoneyMask').mask('00.000.000,00', { reverse: true });
    $('.moneyMask').mask('000.000,00', { reverse: true });

    var SPMaskBehavior = function (val) {
        return val.length > 14 ? '00.000.000/0000-00' : '000.000.000-009999';
    },
    spOptions = {
        onKeyPress: function (val, e, field, options) {
            field.mask(SPMaskBehavior.apply({}, arguments), options);
        }
    };

    $('.defaultCPFMask').mask(SPMaskBehavior, spOptions);

    $('.defaultRootCNPJMask').mask('00.000.000');

    $('.defaultCPFMask2').mask('000.000.000-00');

    $('.defaultCNPJMask2').mask('00.000.000/0000-00', { reverse: true });

    $('.defaultNumberMask').mask('9999999999');

    $('.shorterNumberMask').mask('999999');

    $('.2DigitNumberMask').mask('99');

    $('.3DigitNumberMask').mask("S000", {
        translation: {
            'S': {
                pattern: /-/,
                optional: true
            }
        }
    });

    $('.3DigitPositiveNumberMask').mask('999');

    $('.4DigitNumberMask').mask('9999');

    $('.5DigitNumberMask').mask('99999');

    $('.6DigitNumberMask').mask('999999');

    $('.8DigitNumberMask').mask('99999999');

    $('.10DigitNumberMask').mask('9999999999');

    $('.11DigitNumberMask').mask('99999999999');

    $('.15DigitNumberMask').mask('999999999999999');

    $('.19DigitNumberMask').mask('9999999999999999999');

    $('.20DigitNumberMask').mask('99999999999999999999');

    $('.CreditCardNumber').mask('0000 0000 0000 0000');

    $('.defaultYearMask').mask('0000');

    $('.defaultPercentMask').mask('999');

    $('.defaultCEPMask').mask('99999999');

    $('.defaultCelularMask').mask('99999999999');

    $('.defaultTelefoneMask').mask('9999999999');

    $('.18DigitDecimalMask').mask('999999999999999,99');

    $('.alimentador').mask('SSS00');

    $('.alimentador').keyup(function () {
        this.value = this.value.toLocaleUpperCase();
    });

    //MASK DATA - HORA (HH:MM)
    var initialTimeOptions = {
        onKeyPress: function (val, e, field, options) {
            if (field.val().substring(0, 1) == '2') {
                $(field).mask('00:00', twoBasedTimeOptions);
            }
            else {
                $(field).mask('00:00', otherTimeOptions);
            }
        }, "placeholder": "HH:MM", 'translation': {
            2: { pattern: /[0-2*]/ },
            0: { pattern: /[0-9*]/ },
        }
    },
        twoBasedTimeOptions = {
            onKeyPress: function (val, e, field, options) {
                $(field).mask('00:00', initialTimeOptions);
                if (field.val().substring(0, 1) == '2') {
                    $(field).mask('12:34', twoBasedTimeOptions);
                }
                else {
                    $(field).mask('12:34', otherTimeOptions);
                }
            }, "placeholder": "HH:MM", 'translation': {
                1: { pattern: /[0-2*]/ },
                2: { pattern: /[0-3*]/ },
                3: { pattern: /[0-5*]/ },
                4: { pattern: /[0-9*]/ }
            }
        },
        otherTimeOptions = {
            onKeyPress: function (val, e, field, options) {
                $(field).mask('00:00', initialTimeOptions);
                if (field.val().substring(0, 1) == '2') {
                    $(field).mask('12:34', twoBasedTimeOptions);
                }
                else {
                    $(field).mask('12:34', otherTimeOptions);
                }
            }, "placeholder": "HH:MM", 'translation': {
                1: { pattern: /[0-2*]/ },
                2: { pattern: /[0-9*]/ },
                3: { pattern: /[0-5*]/ },
                4: { pattern: /[0-9*]/ }
            }
        };

    $('.defaultTimeMask').bind('cut copy paste drop', function () { return false; }).mask('20:00', initialTimeOptions);

    //MASK DATA - HORA - SEGUNDOS (HH:MM:SS)
    var initialSecondsOptions = {
        onKeyPress: function (val, e, field, options) {
            if (field.val().substring(0, 1) == '2') {
                $(field).mask('00:00:00', twoBasedSecondsOptions);
            }
            else {
                $(field).mask('00:00:00', otherSecondsOptions);
            }
        }, "placeholder": "HH:MM", 'translation': {
            2: { pattern: /[0-2*]/ },
            0: { pattern: /[0-9*]/ },
        }
    },
        twoBasedSecondsOptions = {
            onKeyPress: function (val, e, field, options) {
                $(field).mask('00:00:00', initialSecondsOptions);
                if (field.val().substring(0, 1) == '2') {
                    $(field).mask('12:34:34', twoBasedSecondsOptions);
                }
                else {
                    $(field).mask('12:34:34', otherSecondsOptions);
                }
            }, "placeholder": "HH:MM", 'translation': {
                1: { pattern: /[0-2*]/ },
                2: { pattern: /[0-3*]/ },
                3: { pattern: /[0-5*]/ },
                4: { pattern: /[0-9*]/ }
            }
        },
        otherSecondsOptions = {
            onKeyPress: function (val, e, field, options) {
                $(field).mask('00:00:00', initialSecondsOptions);
                if (field.val().substring(0, 1) == '2') {
                    $(field).mask('12:34:34', twoBasedSecondsOptions);
                }
                else {
                    $(field).mask('12:34:34', otherSecondsOptions);
                }
            }, "placeholder": "HH:MM", 'translation': {
                1: { pattern: /[0-2*]/ },
                2: { pattern: /[0-9*]/ },
                3: { pattern: /[0-5*]/ },
                4: { pattern: /[0-9*]/ }
            }
        };

    $('.defaultTimeCompleteMask').bind('cut copy paste drop', function () { return false; }).mask('20:00:00', initialSecondsOptions);

    $('.defaultDateMask').mask('99/99/9999');

    $('.defaultPhoneMask').mask('(00) 000000009');

    $('.defaultCelPhoneMask').mask('(00) 000000009');
    $('.defaultPhone2Mask').mask('(00) 000000009');

    $('.defaultRGMask').mask('99.999.999-9')

    $('.defaultAlturaMask').mask('9,99');

    $('.defaultPesoMask').mask('999,99');

    $('.qtdNecessariaMask').mask('0999,9999');

    //Plate
    $('.defaultPlateMask').mask('SSS-0000');

    $('.defaultPlateMask').keyup(function () {
        this.value = this.value.toLocaleUpperCase();
    });

    $('.defaultLetters').keyup(function () {
        this.value = this.value.replace(/[^A-Za-záàâãéèêíïóôõöúçÁÀÂÃÉÈÍÏÓÔÕÖÚÇ ]/g, '');
    });

    $('.defaultLongitudeMask').mask('7099.9999999999999', {
        'translation': {
            7: { pattern: /[\d+-]/ }
        }
    });
    $('.defaultLatitudeMask').mask('799.9999999999999', {
        'translation': {
            7: { pattern: /[\d+-]/ }
        }
    });
}

function LimitaMaxLenghtTextArea(controle, tamanhoMaximo) {
    var text = $(controle).val();
    var textLength = text.length;
    if (textLength > tamanhoMaximo) {
        $(controle).val(text.substring(0, (tamanhoMaximo - 1)));
    }
}

function CarregarPopover(url, params) {

    var conteudo = '';

    $.ajax({
        url: url,
        type: 'GET',

        success: function (result) {
            conteudo = result;
        }
    });

    return conteudo;
}

function PrevisaoTempo(lat, lon, data, callback, callbackFail) {
    // Busca a previsão do tempo via Yahoo Weather. Retorna até 10 dias do momento da execução, incluindo hoje.
    // Parametro DATA deve string DD/MM/YYYY. PARAMETRO CALLBACK é o nome da function que será executada no sucesso.
    // Exemplo: function callback(result) { alert(result); }
    // PrevisaoTempo(-22.8660663, -47.021480399999994, '02/11/2016', callback);

    var dataRetorno = moment(data, 'DD/MM/YYYY');
    var dataMaxima = moment(new Date()).add(10, 'days');

    if (dataRetorno.isBetween(new Date, dataMaxima, 'day', true)) {

        $.ajax({
            url: "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20u%3D'c'%20and%20woeid%20in%20(SELECT%20woeid%20FROM%20geo.places%20WHERE%20text%3D%22(" + lat + "%2C" + lon + ")%22)&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys",
            success: function (response) {
                console.log(response);
                if (response.query.results != null) { // Results pode retornar null e causar exception
                    for (var i = 0; i < response.query.results.channel.item.forecast.length; i++) {
                        var date = moment(response.query.results.channel.item.forecast[i].date, 'DD MMM YYYY');

                        if (date.isSame(dataRetorno)) {
                            var code = response.query.results.channel.item.forecast[i].code;
                            var max = response.query.results.channel.item.forecast[i].high;
                            var min = response.query.results.channel.item.forecast[i].low;
                            var urlImg = 'http://l.yimg.com/a/i/us/we/52/' + code + '.gif';
                            callback([max, min, urlImg]);
                            break;
                        }
                    }
                }
                else
                    callbackFail();
            },
            error: function () {
                callbackFail();
            },
            global: false
        });
    }
    else {
        callbackFail();
    }
}

// Busca a previsão do tempo via Yahoo Weather. Retorna até 10 dias do momento da execução, incluindo hoje.
function PrevisaoTempoMunicipio(municipios, callback, callbackFail) {

    $.ajax({
        url: "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20u%3D'c'%20and%20woeid%20in%20(select%20woeid%20from%20geo.places(1)%20where%20text%20in%20(" + municipios + "))&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys",
        success: function (response) {

            if (response.query.results != null) {
                //retorna array
                callback(response.query.results);
            }
            else
                callbackFail();
        },
        error: function () {
            callbackFail();
        },
        global: false
    });
}

// Busca a previsão do tempo via Yahoo Weather. Retorna apenas 1 dia
function PrevisaoTempoMunicipioDia(municipios, dataPrevisao, callback, callbackFail) {

    $.ajax({
        url: "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20u%3D'c'%20and%20woeid%20in%20(select%20woeid%20from%20geo.places(1)%20where%20text%20in%20(" + municipios + "))&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys",
        success: function (response) {

            if (response.query.results != null) {
                //retorna array
                callback(response.query.results, dataPrevisao);
            }
            else
                callbackFail();
        },
        error: function () {
            callbackFail();
        },
        global: false
    });
}

function FazerImpressao(htmlConteudoImpressao) {
    var conteudoAserImpresso = htmlConteudoImpressao;
    var conteudoOriginal = $("body").html();
    $("body").html(conteudoAserImpresso);
    window.print();
    $("body").html(conteudoOriginal);
}

function AutoCompletePadrao(campoTexto, campoId, url, functionName) {
    $(campoTexto).typeahead({
        hint: true,
        highlight: true,
        minLength: 3
        , source: function (request, response) {
            $(campoTexto).addClass('loadingAutoComplete');
            $.ajax({
                url: url,
                data: "{ 'prefix': '" + request + "'}",
                dataType: "json",
                type: "POST",
                global: false,
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    items = [];
                    map = {};
                    $.each(data, function (i, item) {
                        var id = item.Value;
                        var name = item.Text;
                        map[name] = { id: id, name: name };
                        items.push(item.Text);
                    });
                    response(items);
                    $(".dropdown-menu").css("height", "auto");
                    $(campoTexto).removeClass('loadingAutoComplete');
                },
                error: function (response) {
                    $(campoTexto).removeClass('loadingAutoComplete');
                    alert(response.responseText);
                },
                failure: function (response) {
                    $(campoTexto).removeClass('loadingAutoComplete');
                    alert(response.responseText);
                }
            });
        },
        updater: function (item) {
            $(campoId).val(map[item].id);

            if (functionName != "") {
                var fn = window[functionName];
                if (typeof fn === "function") fn();
            }

            return item;
        }
    }).on('keydown', function (e) {
        $(campoId).val("");
    });
}
var livroOcorrenciaChamado = false;