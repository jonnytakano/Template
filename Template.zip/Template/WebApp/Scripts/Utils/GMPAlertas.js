﻿function ExibeMensagemErro(titulo, mensagem) {
    $('#titulo').html(titulo);
    $('#mensagem').html(mensagem);
    $("#tipoAlerta").attr('class', '');
    $('#tipoAlerta').addClass('alert alert-dismissible alert-danger');
    $('#modalAlerta').modal('show');
}

function ExibeMensagemAlerta(titulo, mensagem) {
    $('#titulo').html(titulo);
    $('#mensagem').html(mensagem);
    $("#tipoAlerta").attr('class', '');
    $('#tipoAlerta').addClass('alert alert-dismissible alert-warning');
    $('#modalAlerta').modal('show');
}

function ExibeMensagemSucesso(titulo, mensagem) {
    $('#titulo').html(titulo);
    $('#mensagem').html(mensagem);
    $("#tipoAlerta").attr('class', '');
    $('#tipoAlerta').addClass('alert alert-dismissible alert-success');
    $('#modalAlerta').modal('show');
}

function ExibeMensagemSucessoTextArea(titulo, mensagem, textArea) {
    $('#tituloTextArea').html(titulo);
    $('#mensagemTextArea').html(mensagem);
    $("#tipoAlertaTextArea").attr('class', '');
    $('#tipoAlertaTextArea').addClass('alert alert-dismissible alert-success');

    if (textArea) {
        $("#placasErro").show();
        $('#textoComplementar').html(textArea);
    }
    else {
        $("#placasErro").hide();
    }

    $('#modalAlertaTextArea').modal('show');
}

function ExibeMensagemConfirmacao(titulo, mensagem) {
    $('#tituloConfirm').html(titulo);
    $('#mensagemConfirm').html(mensagem);
    $("#tipoAlertaConfirm").attr('class', '');
    $('#tipoAlertaConfirm').addClass('alert alert-dismissible alert-warning');
    $('#modalConfirm').modal('show');
}

function ExibeMensangemValidacao(htmlSummary) {

    if ($('#modalAlerta').hasClass('in') === false) {
        var titulo = 'ATENÇÃO!';
        $('#titulo').html(titulo);
        $('#mensagem').html(htmlSummary);
        $("#tipoAlerta").attr('class', '');
        $('#tipoAlerta').addClass('alert alert-dismissible alert-danger');
        $('#modalAlerta').modal('show');
    }
}