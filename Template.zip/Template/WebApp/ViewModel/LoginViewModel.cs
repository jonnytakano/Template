﻿using System.ComponentModel.DataAnnotations;

namespace WebApp.ViewModel
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Matrícula")]
        [Display(Name = "Matrícula")]
        public string Usuario { get; set; }
        [Required(ErrorMessage = "Senha")]
        [Display(Name = "Senha")]
        public string Senha { get; set; }
    }
}