﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Web;

namespace WebApp.Controllers
{
    [Serializable]
    [Authorize]
    public class DashboardController : Controller
    {
        // GET: Dashboard
        public ActionResult Index()
        {

            var oCookie = FormsAuthentication.GetAuthCookie(HttpContext.Request.LogonUserIdentity.Name, false);

            ViewBag.Cookie = oCookie;

            ViewBag.Nome = (Model.Dto.UsuarioSessaoDTO)Session["Usuario"];
            return View();
        }
    }
}