﻿using System;
using System.Web.Mvc;
using WebApp.ViewModel;
using BLL.Login.Interface;
using Microsoft.Practices.ServiceLocation;
using System.Web.Security;

namespace WebApp.Controllers
{
    [Serializable()]
    [AllowAnonymous]
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login(LoginViewModel loginViewModel)
        {
            if (ModelState.IsValid)
            {
                ModelState.Clear();

                ILoginBLO _service = ServiceLocator.Current.GetInstance<ILoginBLO>();
                var login = _service.ValidarLogin(loginViewModel.Usuario, loginViewModel.Senha);

                if (login.Valido)
                {
                    Session["Usuario"] = login.UsuarioSessao;
                    FormsAuthentication.SetAuthCookie(login.UsuarioSessao.Nome, false);
                    return RedirectToAction("Index", "Dashboard");
                }
                else
                {
                    ViewBag.ErroUsuario = "Seu acesso no sistema não possui centro de operações cadastrado. Contate seu superior para esclarecimentos. ";
                }
                return View("Index", loginViewModel);
            }
            else
            {
                return View("Index", loginViewModel);
            }
        }

        [Authorize]
        public RedirectToRouteResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index");
        }
    }
}