﻿using CPFL.COM.Template.Data.Context;
using CPFL.COM.Template.Data.Context.Interfaces;
using Ninject.Modules;

namespace CPFL.COM.Template.CrossCutting.InversionOfControl.Modules
{
    public class InfrastructureNinjectModule : NinjectModule
    {
        public override void Load()
        {
            Bind<IDbContext>().To<DatabaseContext>();
            Bind(typeof(IContextManager<>)).To(typeof(ContextManager<>));
            Bind(typeof(IUnitOfWork<>)).To((typeof(UnitOfWork<>)));
        }
    }
}