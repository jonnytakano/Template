﻿using CPFL.COM.Template.Data.Repository.EntityFramework;
using CPFL.COM.Template.Data.Repository.EntityFramework.Common;
using CPFL.COM.Template.Domain.Interfaces.Repository;
using CPFL.COM.Template.Domain.Interfaces.Repository.Common;
using Ninject.Modules;

namespace CPFL.COM.Template.CrossCutting.InversionOfControl.Modules
{
    public class RepositoryNinjectModule : NinjectModule
    {
        public override void Load()
        {
            Bind(typeof(IRepository<>)).To(typeof(Repository<>));

            Bind<ILogAppRepository>().To<LogAppRepository>();
            Bind<IUsuarioRepository>().To<UsuarioRepository>();
            Bind<IGrupoAplicacaoRepository>().To<GrupoAplicacaoRepository>();
            Bind<ISubGrupoAplicacaoRepository>().To<SubGrupoAplicacaoRepository>();
            Bind<IAplicacaoRepository>().To<AplicacaoRepository>();
            Bind<IPerfilRepository>().To<PerfilRepository>();
            Bind<IPerfilAplicacaoRepository>().To<PerfilAplicacaoRepository>();

            //Bind<IUsuarioRepository>().To<UsuarioRepository>();
            //Bind<IUsuarioReadOnlyRepository>().To<UsuarioDapperRepository>();
            //Bind<IReadOnlyRepository<Usuario>>().To<UsuarioDapperRepository>();

            //Bind<IUsuarioReadOnlyRepository>().To<UsuarioDapperRepository>();
            //Bind<IReadOnlyRepository<Usuario>>().To<UsuarioDapperRepository>();

            //Bind<IUsuarioReadOnlyRepository>().To<UsuarioDapperRepository>();
            //Bind<IReadOnlyRepository<Usuario>>().To<UsuarioDapperRepository>();
        }
    }
}