﻿using CPFL.COM.Template.Service;
using CPFL.COM.Template.Service.Interfaces;
using Ninject.Modules;

namespace CPFL.COM.Template.CrossCutting.InversionOfControl.Modules
{
    public class ServiceNinjectModule : NinjectModule
    {
        public override void Load()
        {
            Bind<ILogAppAppService>().To<LogAppAppService>();
            Bind<IUsuarioService>().To<UsuarioService>();
            Bind<IAplicacaoService>().To<AplicacaoService>();
            Bind<IGrupoAplicacaoService>().To<GrupoAplicacaoService>();
            Bind<ISubGrupoAplicacaoService>().To<SubGrupoAplicacaoService>();
            Bind<IPerfilService>().To<PerfilService>();
            Bind<IPerfilAplicacaoService>().To<PerfilAplicacaoService>();
        }
    }
}