﻿using CommonServiceLocator.NinjectAdapter.Unofficial;
using CPFL.COM.Template.CrossCutting.InversionOfControl.Modules;
using Microsoft.Practices.ServiceLocation;
using Ninject;

namespace CPFL.COM.Template.CrossCutting.InversionOfControl
{
    public class IoC
    {
        public IKernel Kernel { get; private set; }

        public IoC()
        {
            Kernel = GetNinjectModules();
            ServiceLocator.SetLocatorProvider(() => new NinjectServiceLocator(Kernel));            
        }

        public StandardKernel GetNinjectModules()
        {
            return new StandardKernel(
                new ServiceNinjectModule(),
                new InfrastructureNinjectModule(),
                new RepositoryNinjectModule());
        }
    }
}