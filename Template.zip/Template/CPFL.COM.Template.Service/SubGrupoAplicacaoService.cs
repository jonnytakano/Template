﻿using CPFL.COM.Template.Data.Context;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository;
using CPFL.COM.Template.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace CPFL.COM.Template.Service
{
    public class SubGrupoAplicacaoService : AppService<DatabaseContext>, ISubGrupoAplicacaoService
    {

        private readonly ISubGrupoAplicacaoRepository _repository;

        public SubGrupoAplicacaoService(ISubGrupoAplicacaoRepository SubGrupoAplicacaoRepository)
        {
            _repository = SubGrupoAplicacaoRepository;
        }

        public SubGrupoAplicacao Get(long id)
        {
            return _repository.Get(id);
        }

        public void Add(SubGrupoAplicacao entity)
        {
            this.BeginTransaction();
            _repository.Add(entity);
            this.Commit();
        }

        public void Update(SubGrupoAplicacao entity)
        {
            this.BeginTransaction();
            _repository.Update(entity);
            this.Commit();
        }

        public void Delete(SubGrupoAplicacao entity)
        {
            this.BeginTransaction();
            _repository.Delete(entity);
            this.Commit();
        }

        public IEnumerable<SubGrupoAplicacao> All()
        {
            return _repository.All();
        }

        public IEnumerable<SubGrupoAplicacao> Find(Expression<Func<SubGrupoAplicacao, bool>> predicate)
        {
            return _repository.Find(predicate);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }

}

