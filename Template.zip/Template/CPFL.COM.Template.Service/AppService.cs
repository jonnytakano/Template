﻿using CPFL.COM.Template.Data.Context.Interfaces;
using CPFL.COM.Template.Service.Interfaces.Common;
using Microsoft.Practices.ServiceLocation;

namespace CPFL.COM.Template.Service
{
    public class AppService<TContext> : ITransactionAppService<TContext>
       where TContext : IDbContext, new()
    {
        private IUnitOfWork<TContext> _uow;

        public AppService()
        {
        }

        public virtual void BeginTransaction()
        {
            _uow = ServiceLocator.Current.GetInstance<IUnitOfWork<TContext>>();
            _uow.BeginTransaction();
        }

        public virtual void Commit()
        {
            _uow.SaveChanges();
        }
    }
}