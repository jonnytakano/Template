﻿using CPFL.COM.Template.Data.Context;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository;
using CPFL.COM.Template.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace CPFL.COM.Template.Service
{
    public class LogAppAppService : AppService<DatabaseContext>, ILogAppAppService
    {
        private readonly ILogAppRepository _repository;

        public LogAppAppService(ILogAppRepository usuarioRepository)
        {
            _repository = usuarioRepository;
        }

        public LogApp Get(long id)
        {
            return _repository.Get(id);
        }

        public void Add(LogApp entity)
        {
            this.BeginTransaction();
            _repository.Add(entity);
            this.Commit();
        }

        public void Update(LogApp entity)
        {
            this.BeginTransaction();
            _repository.Update(entity);
            this.Commit();
        }

        public void Delete(LogApp entity)
        {
            this.BeginTransaction();
            _repository.Delete(entity);
            this.Commit();
        }

        public IEnumerable<LogApp> All()
        {
            return _repository.All();
        }

        public IEnumerable<LogApp> Find(Expression<Func<LogApp, bool>> predicate)
        {
            return _repository.Find(predicate);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

    }
}