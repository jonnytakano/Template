﻿using CPFL.COM.Template.Data.Context;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository;
using CPFL.COM.Template.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace CPFL.COM.Template.Service
{
    public class GrupoAplicacaoService : AppService<DatabaseContext>, IGrupoAplicacaoService
    {

        private readonly IGrupoAplicacaoRepository _repository;

        public GrupoAplicacaoService(IGrupoAplicacaoRepository GrupoAplicacaoRepository)
        {
            _repository = GrupoAplicacaoRepository;
        }

        public GrupoAplicacao Get(long id)
        {
            return _repository.Get(id);
        }

        public void Add(GrupoAplicacao entity)
        {
            this.BeginTransaction();
            _repository.Add(entity);
            this.Commit();
        }

        public void Update(GrupoAplicacao entity)
        {
            this.BeginTransaction();
            _repository.Update(entity);
            this.Commit();
        }

        public void Delete(GrupoAplicacao entity)
        {
            this.BeginTransaction();
            _repository.Delete(entity);
            this.Commit();
        }

        public IEnumerable<GrupoAplicacao> All()
        {
            return _repository.All();
        }

        public IEnumerable<GrupoAplicacao> Find(Expression<Func<GrupoAplicacao, bool>> predicate)
        {
            return _repository.Find(predicate);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }

}

