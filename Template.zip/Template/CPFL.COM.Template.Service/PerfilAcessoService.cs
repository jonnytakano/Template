﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using CPFL.COM.Template.Data.Context;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository;
using CPFL.COM.Template.Service.Interfaces;

namespace CPFL.COM.Template.Service
{
	public class PerfilAplicacaoService : AppService<DatabaseContext>, IPerfilAplicacaoService
	{
		private readonly IPerfilAplicacaoRepository _repository;

		public PerfilAplicacaoService(IPerfilAplicacaoRepository perfilRepository)
		{
			_repository = perfilRepository;
		}

		public PerfilAplicacao Get(long id)
		{
			return _repository.Get(id);
		}

		public void Add(PerfilAplicacao entity)
		{
			this.BeginTransaction();
			_repository.Add(entity);
			this.Commit();
		}

		public void Update(PerfilAplicacao entity)
		{
			this.BeginTransaction();
			_repository.Update(entity);
			this.Commit();
		}

		public void Delete(PerfilAplicacao entity)
		{
			this.BeginTransaction();
			_repository.Delete(entity);
			this.Commit();
		}

		public IEnumerable<PerfilAplicacao> All()
		{
			return _repository.All();
		}

		public IEnumerable<PerfilAplicacao> Find(Expression<Func<PerfilAplicacao, bool>> predicate)
		{
			return _repository.Find(predicate);
		}

		public void Dispose()
		{
			GC.SuppressFinalize(this);
		}
	}
}
