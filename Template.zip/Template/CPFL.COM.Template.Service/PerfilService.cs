﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using AuthiUtilities;
using CPFL.COM.Template.Data.Context;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository.Common;
using CPFL.COM.Template.Domain.ViewModel;
using CPFL.COM.Template.Service.Interfaces;

namespace CPFL.COM.Template.Service
{
	public class PerfilService : AppService<DatabaseContext>, IPerfilService
	{
		private readonly IPerfilRepository _repository;

		public PerfilService(IPerfilRepository perfilRepository)
		{
			_repository = perfilRepository;
		}

		public Perfil Get(long id)
		{
			return _repository.Get(id);
		}

		public void Add(Perfil entity)
		{
			this.BeginTransaction();
			_repository.Add(entity);
            this.Commit();
		}

		public void Update(Perfil entity)
		{
			this.BeginTransaction();
			_repository.Update(entity);
			this.Commit();
		}

		public void Delete(Perfil entity)
		{
			this.BeginTransaction();
			_repository.Delete(entity);
			this.Commit();
		}

		public IEnumerable<Perfil> All()
		{
			return _repository.All();
		}

		public IEnumerable<Perfil> Find(Expression<Func<Perfil, bool>> predicate)
		{
			return _repository.Find(predicate);
		}

        public List<SelectListItem> ListItens()
        {
            return _repository
                .Find(q => q.Ativo)
                .Select(q => new SelectListItem { Value = q.Id.ToString(), Text = q.Nome })
                .ToList();
        }

        public IOrderedQueryable<Perfil> Filter(PerfilViewModel entity, int page)
        {
            if (entity == null) { entity = new PerfilViewModel(); }

            return _repository.Filter(entity, page);
        }

        public void Dispose()
		{
			GC.SuppressFinalize(this);
		}
	}
}
