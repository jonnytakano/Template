﻿using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.ViewModel;
using CPFL.COM.Template.Service.Interfaces.Common;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace CPFL.COM.Template.Service.Interfaces
{
    public interface IPerfilService : IAppService<Perfil>
	{
        List<SelectListItem> ListItens();
        IOrderedQueryable<Perfil> Filter(PerfilViewModel entity, int page);

    }
}
