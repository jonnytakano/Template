﻿using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Service.Interfaces.Common;

namespace CPFL.COM.Template.Service.Interfaces
{
    public interface ILogAppAppService : IAppService<LogApp>
    {
        
    }
}