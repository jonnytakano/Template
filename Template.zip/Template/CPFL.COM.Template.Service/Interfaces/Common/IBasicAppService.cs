﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace CPFL.COM.Template.Service.Interfaces.Common
{
    public interface IAppService<TEntity> : IDisposable
        where TEntity : class
    {
        TEntity Get(long id);
        void Add(TEntity entity);
        void Update(TEntity entity);
        void Delete(TEntity entity);
        IEnumerable<TEntity> All();
        IEnumerable<TEntity> Find(Expression<Func<TEntity, bool>> predicate);
    }
}