﻿using CPFL.COM.Template.Data.Context.Interfaces;

namespace CPFL.COM.Template.Service.Interfaces.Common
{
    public interface ITransactionAppService<TContext>
       where TContext : IDbContext, new()
    {
        void BeginTransaction();
        void Commit();
    }
}