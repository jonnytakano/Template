﻿
namespace CPFL.COM.Template.Service.Interfaces.Common
{
    public interface IWriteOnlyAppService<in TEntity>
   where TEntity : class
    {
    }
}