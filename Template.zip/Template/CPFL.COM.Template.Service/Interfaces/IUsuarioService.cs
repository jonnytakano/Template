﻿using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.ViewModel;
using CPFL.COM.Template.Service.Interfaces.Common;
using System.Linq;

namespace CPFL.COM.Template.Service.Interfaces
{
    public interface IUsuarioService : IAppService<Usuario>
    {
        Usuario GetByMatricula(string matricula);

        IOrderedQueryable<Usuario> Filter(UsuarioViewModel entity, int page);

        Usuario InformacoesUsuario(string matricula = "");
    }
}