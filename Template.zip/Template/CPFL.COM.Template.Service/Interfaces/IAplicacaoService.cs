﻿using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Service.Interfaces.Common;
using System.Collections.Generic;

namespace CPFL.COM.Template.Service.Interfaces
{
    public interface IAplicacaoService : IAppService<Aplicacao>
    {
        List<Aplicacao> RecuperaNovasAplicacoes(long idPerfil);
    }
}
