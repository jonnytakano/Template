﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Service.Interfaces.Common;

namespace CPFL.COM.Template.Service.Interfaces
{
	public interface IPerfilAplicacaoService : IAppService<PerfilAplicacao>
	{

	}
}
