﻿using CPFL.COM.Template.Data.Context;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository;
using CPFL.COM.Template.Domain.ViewModel;
using CPFL.COM.Template.Service.Interfaces;
using CPFL.CORP.PortalCoordWEB.Common;
using PagedList;
using System;
using System.Collections.Generic;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Linq.Expressions;

namespace CPFL.COM.Template.Service
{
    public class UsuarioService : AppService<DatabaseContext>, IUsuarioService
    {
        private readonly IUsuarioRepository _repository;

        public UsuarioService(IUsuarioRepository usuarioRepository)
        {
            _repository = usuarioRepository;
        }

        public Usuario Get(long id)
        {
            return _repository.Get(id);
        }

        public void Add(Usuario entity)
        {
            this.BeginTransaction();
            _repository.Add(entity);
            this.Commit();
        }

        public void Update(Usuario entity)
        {
            this.BeginTransaction();
            _repository.Update(entity);
            this.Commit();
        }

        public void Delete(Usuario entity)
        {
            this.BeginTransaction();
            _repository.Delete(entity);
            this.Commit();
        }

        public IEnumerable<Usuario> All()
        {
            return _repository.All();
        }

        public IEnumerable<Usuario> Find(Expression<Func<Usuario, bool>> predicate)
        {
            return _repository.Find(predicate);
        }

        public IOrderedQueryable<Usuario> Filter(UsuarioViewModel entity, int page)
        {
            if (entity == null) { entity = new UsuarioViewModel(); }

            return _repository.Filter(entity, page);
        }

        public Usuario GetByMatricula(string matricula)
        {
            return _repository.GetByMatricula(matricula);
        }

        public Usuario InformacoesUsuario(string matricula = "")
        {
            var usuario = new ActiveDirectoryManager();

            UserPrincipal InfoUsuario = usuario.BuscarUsuarioAD(matricula);

            Usuario user = null;

            if (InfoUsuario != null)
            {
                user = new Usuario();
                user.Nome = InfoUsuario.DisplayName;
                user.Matricula = InfoUsuario.SamAccountName;

                user.Empresa = InfoUsuario.GetCompany();
                user.Email = InfoUsuario.EmailAddress;
            }        

            return user;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}