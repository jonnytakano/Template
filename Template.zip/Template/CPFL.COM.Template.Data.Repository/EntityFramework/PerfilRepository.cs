﻿using System.Collections.Generic;
using System.Linq;
using CPFL.COM.Template.Data.Context;
using CPFL.COM.Template.Data.Repository.EntityFramework.Common;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository;
using CPFL.COM.Template.Domain.Interfaces.Repository.Common;
using CPFL.COM.Template.Domain.ViewModel;

namespace CPFL.COM.Template.Data.Repository.EntityFramework
{
	public class PerfilRepository : Repository<Perfil>, IPerfilRepository
	{
        //public override void Add(Perfil entity)
        //{
        //    foreach (var item in entity.PerfilAplicacao)
        //    {
        //        this.Context.Set<PerfilAplicacao>().Attach(item);
        //        //this.Context.Set<PerfilAplicacao>().Add(item);
        //    }
        //    this.DbSet.Attach(entity);
        //    base.Add(entity);
        //}

        public IOrderedQueryable<Perfil> Filter(PerfilViewModel entity, int page)
        {
            var query = this.DbSet.AsQueryable();

            if (!entity.FiltroAtivo)
            {
                query = query.Where(q => q.Ativo);
            }

            if (!string.IsNullOrEmpty(entity.FiltroNome))
            {
                query = query.Where(q => q.Nome.ToUpper().Contains(entity.FiltroNome.ToUpper()));
            }

            return query.OrderBy(q => q.Nome);
        }
    }
}
