﻿using CPFL.COM.Template.Data.Repository.EntityFramework.Common;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository;
using CPFL.COM.Template.Domain.ViewModel;
using PagedList;
using System;
using System.Linq;

namespace CPFL.COM.Template.Data.Repository.EntityFramework
{
    public class UsuarioRepository : Repository<Usuario>, IUsuarioRepository
    {
        public Usuario GetByMatricula(string matricula)
        {
            var obj = this.DbSet.
                Where(q => q.Matricula.ToUpper() == matricula.ToUpper()
                && q.Ativo)
                .SingleOrDefault();

            return obj;
        }

        public IOrderedQueryable<Usuario> Filter(UsuarioViewModel entity, int page)
        {
            var query = this.DbSet.AsQueryable();

            if (!entity.FiltroAtivo)
            {
                query = query.Where(q => q.Ativo);
            }

            if (!string.IsNullOrEmpty(entity.FiltroMatricula))
            {
                query = query.Where(q => q.Matricula.ToUpper() == entity.FiltroMatricula.ToUpper());
            }

            if (!string.IsNullOrEmpty(entity.FiltroNome))
            {
                query = query.Where(q => q.Nome.ToUpper().Contains(entity.FiltroNome.ToUpper()));
            }

            return query.OrderBy(q => q.Nome);
        }
    }
}