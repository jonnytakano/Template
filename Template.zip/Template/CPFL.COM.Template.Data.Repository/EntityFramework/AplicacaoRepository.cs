﻿using CPFL.COM.Template.Data.Repository.EntityFramework.Common;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository;
using System.Collections.Generic;
using System.Linq;

namespace CPFL.COM.Template.Data.Repository.EntityFramework
{
    public class AplicacaoRepository : Repository<Aplicacao>, IAplicacaoRepository
    {
        public List<Aplicacao> RecuperaNovasAplicacoes(long idPerfil)
        {
            var idpAplicacoesExistentes = this.Context.Set<PerfilAplicacao>()
                .Where(q => q.IdPerfil == idPerfil)
                .Select(q => q.IdAplicacao);

            var query = this.DbSet
                .Where(q => !idpAplicacoesExistentes.Contains(q.Id));

            return query.ToList();
        }
    }
}