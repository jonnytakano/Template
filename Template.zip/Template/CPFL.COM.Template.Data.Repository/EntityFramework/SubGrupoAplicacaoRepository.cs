﻿using CPFL.COM.Template.Data.Repository.EntityFramework.Common;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository;

namespace CPFL.COM.Template.Data.Repository.EntityFramework
{
    public class SubGrupoAplicacaoRepository : Repository<SubGrupoAplicacao>, ISubGrupoAplicacaoRepository
    {
    }
}
