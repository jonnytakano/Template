﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CPFL.COM.Template.Data.Context;
using CPFL.COM.Template.Data.Repository.EntityFramework.Common;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository;

namespace CPFL.COM.Template.Data.Repository.EntityFramework
{
	public class PerfilAplicacaoRepository : Repository<PerfilAplicacao>, IPerfilAplicacaoRepository
	{
		#region deletar?
		//private DatabaseContext db = new DatabaseContext();

		///// <summary>
		///// Insere um Perfil de Acesso
		///// </summary>
		///// <param name="perfilAcesso">Entidade do Perfil Acesso</param>
		///// <returns>retorna inteiro 1 ou 0</returns>
		//public int Inserir(PerfilAcesso perfilAcesso)
		//{
		//	db.PerfilAcesso.Add(perfilAcesso);
		//	int retorno = db.SaveChanges();

		//	return retorno;
		//}

		///// <summary>
		///// Consulta usuário por matricula
		///// </summary>
		///// <param name="matricula"></param>
		///// <returns></returns>
		//public PerfilAcesso GetUsuario(string idPerfilAcesso)
		//{
		//	var perfilAcesso = db.PerfilAcesso.Where(p => p.IdPerfilAcesso.Equals(idPerfilAcesso)).FirstOrDefault();

		//	return perfilAcesso;
		//}
		#endregion
	}
}
