﻿using System;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;

namespace System
{
    public static class AccountManagementExtensions
    {
        public static String GetProperty(this UserPrincipal principal, String property)
        {
            DirectoryEntry directoryEntry = principal.GetUnderlyingObject() as DirectoryEntry;
            if (directoryEntry.Properties.Contains(property))
                return directoryEntry.Properties[property].Value.ToString();
            else
                return String.Empty;
        }

        public static String GetCompany(this UserPrincipal principal)
        {
            return principal.GetProperty("company");
        }

        public static String GetDepartment(this UserPrincipal principal)
        {
            return principal.GetProperty("department");
        }

    }
}