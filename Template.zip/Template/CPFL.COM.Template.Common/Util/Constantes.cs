﻿namespace System
{
    public static class Const
    {
        public const string AmbientePROD = "PRD";
        public const string AmbienteQA = "QA";
        public const string AmbienteDEV = "DEV";

        public const int RecordCountPerPage = 10;
        public const long PerfilAdmin = 1;
    }
}