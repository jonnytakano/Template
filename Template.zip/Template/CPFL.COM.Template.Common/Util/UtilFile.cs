﻿using System;

namespace CPFL.COM.Template.Common
{
    public static class UtilFile
    {
        public static string RetornaCaminhoImagem(string urlSistema, object obj, string nomeImagem, int width, int height)
        {
            return String.Format("{0}/image/{1}/{4}/{2}/{3}", urlSistema, obj.GetType().ToString(), nomeImagem, width, height);
        }
    }
}