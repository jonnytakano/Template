﻿using System.Collections.Generic;

namespace System
{
    public static class Messages
    {
        #region Mensagens de Apresentação

        /// <summary>
        /// Confirma a exclusão do item?
        /// </summary>
        public const string MA0001 = "Confirma a exclusão do item?";
        /// <summary>
        /// Confirma a inclusão do item?
        /// </summary>
        public const string MA0002 = "Confirma a inclusão do item?";
        /// <summary>
        /// Confirma a alteração do item??
        /// </summary>
        public const string MA0003 = "Confirma a alteração do item?";
        /// <summary>
        /// Confirma a gravação das informações?
        /// </summary>
        public const string MA0004 = "Confirma a gravação das informações?";
        /// <summary>
        /// O meio de comunicação {0} com o valor {1} já está cadastrado como principal.
        /// </summary>
        private const string mA0005 = "O meio de comunicação {0} com o valor {1} já está cadastrado como principal.";
        /// <summary>
        /// O meio de comunicação {0} com o valor {1} já está cadastrado como principal.
        /// </summary>
        public static string MA0005(string tipoMeioComunicacao, string valor)
        {
            return string.Format(mA0005, tipoMeioComunicacao, valor);
        }
        /// <summary>
        /// O endereço {0} do tipo {1} já está cadastrado como principal.
        /// </summary>
        private const string mA0006 = "O endereço {0} do tipo {1} já está cadastrado como principal.";
        /// <summary>
        /// O endereço {0} do tipo {1} já está cadastrado como principal.
        /// </summary>
        public static string MA0006(string endereco, string tipoEndereco)
        {
            return string.Format(mA0006, endereco, tipoEndereco);
        }

        /// <summary>
        /// Deseja ATIVAR este item?
        /// </summary>
        public const string MA0007 = "Deseja ATIVAR este item?";

        /// <summary>
        /// Deseja INATIVAR este item?
        /// </summary>
        public const string MA0008 = "Deseja INATIVAR este item?";


        #endregion

        #region Mensagens de Hint

        /// <summary>
        /// Escolha a imagem
        /// </summary>
        public const string MH0001 = "Escolha a imagem.";

        #endregion

        #region Mensagens de Negócio

        /// <summary>
        /// Esse registro já existe cadastrado, impossível duplicar.
        /// </summary>
        public const string MN0001 = "Esse registro já existe cadastrado, impossível duplicar.";
        /// <summary>
        /// Não é possível alterar o item devido a: {0}.
        /// </summary>
        private const string mN0002 = "Não é possível alterar o item devido a: {0}.";
        /// <summary>
        /// Dados inseridos com sucesso.
        /// </summary>
        public const string MN0003 = "Dados inseridos com sucesso.";
        /// <summary>
        /// Dados alterados com sucesso.
        /// </summary>
        public const string MN0004 = "Dados alterados com sucesso.";
        /// <summary>
        /// Campos obrigatórios não preenchidos: <br />{0}
        /// </summary>
        private const string mN0005 = "Campos obrigatórios não preenchidos: <br />{0}";
        /// <summary>
        /// Nenhum usuário com o login correspondente aos dados digitados foi encontrado.
        /// </summary>
        public const string MN0006 = "Nenhum usuário com o login correspondente aos dados digitados foi encontrado.";
        /// <summary>
        /// Uma mensagem foi enviada para o seu e-mail, contendo sua senha de acesso.
        /// </summary>
        public const string MN0007 = "Uma mensagem foi enviada para o seu e-mail, contendo sua senha de acesso.";
        /// <summary>
        /// As senhas digitadas não são iguais.
        /// </summary>
        public const string MN0008 = "As senhas digitadas não são iguais.";
        /// <summary>
        /// Você não possui permissão para acessar esta funcionalidade.
        /// </summary>
        public const string MN0009 = "Você não possui permissão para acessar esta funcionalidade.";
        /// <summary>
        /// A data final não pode ser inferior a data inicial.
        /// </summary>
        public const string MN0010 = "A data final não pode ser inferior a data inicial.";
        /// <summary>
        /// A data final não pode ser inferior a data atual.
        /// </summary>
        public const string MN0011 = "A data final não pode ser inferior a data atual.";
        /// <summary>
        /// A data final não pode ser nula quando a data de início está preenchida.
        /// </summary>
        public const string MN0012 = "A data final não pode ser nula quando a data de início está preenchida.";
        /// <summary>
        /// A data de início não pode ser nula quando a data final está preenchida.
        /// </summary>
        public const string MN0013 = "A data de início não pode ser nula quando a data final está preenchida.";
        /// <summary>
        /// Informe pelo menos 1 meio de comunicação.
        /// </summary>
        public const string MN0014 = "Informe pelo menos UM meio de comunicação.";

        /// <summary>
        /// Operação realizada com sucesso.
        /// </summary>
        public const string MN0015 = "Operação realizada com sucesso.";

        /// <summary>
        /// {0} Inválid {1}.
        /// </summary>
        private const string mN0016 = "{0} Inválid{1}.";

        /// <summary>
        ///Impossível inativar. Existem usuários ativos associados a esse perfil.
        /// </summary>
        public const string MN0017 = "Impossível inativar. Existem usuários ativos associados a esse perfil.";

        /// <summary>
        /// Ao menos UM telefone deve ser informado..
        /// </summary>
        public const string MN0018 = "Ao menos UM telefone deve ser informado.";

        /// <summary>
        /// Impossível ativar. Já existe uma subcategoria ativa com esse nome.
        /// </summary>
        public const string MN0019 = "Impossível ativar. Já existe uma subcategoria ativa com esse nome.";

        /// <summary>
        /// Impossível ativar. Já existe uma categoria ativa com esse nome.
        /// </summary>
        public const string MN0020 = "Impossível ativar. Já existe uma categoria ativa com esse nome.";

        /// <summary>
        /// {0} já está em uso.
        /// </summary>
        public const string mN0021 = "{0} já está em uso.";

        /// <summary>
        ///  A data de nascimento não pode ser superior à data atual.
        /// </summary>
        public const string mN0022 = " A data de {0} não pode ser superior à data atual.";

        /// <summary>
        /// Usuário Bloqueado. Contate o administrador do sistema.
        /// </summary>
        public const string MN0023 = " Usuário bloqueado. Contate o administrador do sistema.";

        /// <summary>
        /// O cpf informado é inválido.
        /// </summary>
        public const string MN0024 = " O cpf informado é inválido.";

        /// <summary>
        /// O cnpj informado é inválido.
        /// </summary>
        public const string MN0025 = " O cnpj informado é inválido.";

        /// <summary>
        ///Impossível inativar. Existem plataformas associadas a essa profissão.
        /// </summary>
        public const string MN0026 = "Impossível inativar. Existem plataformas associadas a essa profissão.";

        /// <summary>
        ///Impossível inativar. Existem plataformas associadas a esse campo totem.
        /// </summary>
        public const string MN0027 = "Impossível inativar. Existem plataformas associadas a esse campo totem.";

        /// <summary>
        ///Impossível inativar. Existem plataformas associadas a essa forma de pagamento.
        /// </summary>
        public const string MN0028 = "Impossível inativar. Existem plataformas associadas a essa forma de pagamento.";

        /// <summary>
        ///Para completar a operação você deve finalizar a edição do Prêmio clicando em 'Adicionar'
        /// </summary>
        public const string MN0029 = "Para completar a operação você deve finalizar a edição do Prêmio clicando em 'Adicionar'";

        /// <summary>
        ///O e-mail informado está inválido.
        /// </summary>
        public const string MN0030 = "O e-mail informado está inválido.";

        /// <summary>
        ///Chave inválida.
        /// </summary>
        public const string MN0031 = "Chave inválida.";

        /// <summary>
        ///Usuário não encontrado.
        /// </summary>
        public const string MN0032 = "Usuário não encontrado.";

        /// <summary>
        /// Usuário não possui o perfil de lojista.
        /// </summary>
        public const string MN0033 = "Usuário não possui o perfil de lojista.";

        /// <summary>
        /// A senha atual é inválida.
        /// </summary>
        public const string MN0034 = "A senha atual é inválida.";

        /// <summary>
        /// Informe um intervalo (Campos 'De:' e 'Até:') de  data promocionada ou escolha ao menos um dia da semana.
        /// </summary>
        public const string MN0035 = "Informe um intervalo (Campos 'De:' e 'Até:') de  data promocionada ou escolha ao menos um dia da semana.";

        /// <summary>
        /// Campo 'De:' obrigatório para intervalos de datas.
        /// </summary>
        public const string MN0036 = "Campo 'De:' obrigatório para intervalos de datas.";

        /// <summary>
        /// Campo 'Até:' obrigatório para intervalos de datas.
        /// </summary>
        public const string MN0037 = "Campo 'Até:' obrigatório para intervalos de datas.";

        /// <summary>
        /// Data promocionada deve estar dentro dos limites da campanha.
        /// </summary>
        public const string MN0038 = "Data promocionada deve estar dentro dos limites da campanha.";

        /// <summary>
        /// Data promocionada deve estar dentro dos limites da campanha.
        /// </summary>
        public const string MN0039 = "Data promocionada deve estar dentro dos limites da campanha.";

        /// <summary>
        /// Fator da Data Promocionada deve ser informado.
        /// </summary>
        public const string MN0040 = "Fator da Data Promocionada deve ser informado.";

        /// <summary>
        /// Esta forma de pagamento já foi adicionada anteriormente.
        /// </summary>
        public const string MN0041 = "Esta forma de pagamento já foi adicionada anteriormente.";

        /// <summary>
        /// Informe uma data de {0} válida..
        /// </summary>
        public const string mN0042 = "Informe uma data de {0} válida.";

        /// <sumary>
        /// Para continuidade do cadastro, é necessário aceitar os termos e as condições do regulamento.
        /// </sumary>
        public const string MN0043 = "Para continuidade do cadastro, é necessário aceitar os termos e as condições do regulamento.";

        /// <sumary>
        /// Este usuário está inativo. Entre em contato com o administrador.
        /// </sumary>
        public const string MN0044 = "Este usuário está inativo. Entre em contato com o administrador.";

        /// <sumary>
        /// Este {0} já encontra-se cadastrado nesta plataforma.
        /// </sumary>
        public const string mN0045 = "Este {0} já encontra-se cadastrado nesta plataforma.";

        /// <summary>
        /// 
        /// </summary>
        /// <param name="campo"></param>
        /// <returns></returns>
        public static string MN0045(string campo)
        {
            return String.Format(mN0045, campo);
        }

        /// <summary>
        /// Matrícula não encontrada
        /// </summary>
        public const string MN0046 = "Matrícula não encontrada";

        /// <summary>
        /// Não é possível alterar o item devido a: {0}
        /// </summary>
        /// <param name="motivos">{0} - O(s) motivo(s) pelo qual(ais) o item não pode ser alterado.</param>
        public static string MN0002(string motivos)
        {
            return String.Format(mN0002, motivos);
        }
        /// <summary>
        /// Campos obrigatórios não preenchidos: <br />{0}
        /// </summary>
        /// <param name="camposNaoPreenchidos">{0} - Lista contendo os nomes dos campos obrigatórios que não foram preenchidos.</param>
        public static string MN0005(List<string> camposNaoPreenchidos)
        {
            return String.Format(mN0005, String.Join("<br />", camposNaoPreenchidos));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="campo"></param> O campo sendo validado
        /// <param name="genero"></param> Se o campo é genero feminino ou masculino. (Inválida ou Inválido)
        /// <returns></returns>
        public static string MN0016(string campo, bool generoMasculino = true)
        {

            var invalido = generoMasculino ? "o" : "a";
            return String.Format(mN0016, campo, invalido);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="campo"></param>
        /// <returns></returns>
        public static string MN0021(string campo)
        {
            return String.Format(mN0021, campo);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="campo"></param>
        /// <returns></returns>
        public static string MN0042(string campo)
        {
            return String.Format(mN0042, campo);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="campo"></param>
        /// <returns></returns>
        public static string MN0022(string campo)
        {
            return String.Format(mN0022, campo);
        }


        #endregion

    }
}