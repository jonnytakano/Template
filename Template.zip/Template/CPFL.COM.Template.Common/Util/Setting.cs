﻿using System.Configuration;

namespace System
{
    public static class Setting
    {
        public static string Get(string name)
        {
            return ConfigurationManager.AppSettings[name];
        }
        
        public static string SystemName
        {
            get
            {
                return Setting.Get("systemName");
            }
        }

        public static string SystemOwnerNotify
        {
            get
            {
                return Setting.Get("systemOwnerNotify");
            }
        }

        public static string DefaultColor
        {
            get
            {
                return Setting.Get("defaultColor");
            }
        }

        public static string MenuColor
        {
            get
            {
                return Setting.Get("menuColor");
            }
        }

        public static string SecondaryColor
        {
            get
            {
                return Setting.Get("secondaryColor");
            }
        }
        
        public static string URLImageEditor
        {
            get
            {
                return Setting.Get("URLImageEditor");
            }
        }

        public static string ImagemPathEditor
        {
            get
            {
                return Setting.Get("ImagemPathEditor");
            }
        }

        public static string AmbienteAplicacao
        {
            get
            {
                return Setting.Get("ambienteAplicacao");
            }
        }
    }
}
