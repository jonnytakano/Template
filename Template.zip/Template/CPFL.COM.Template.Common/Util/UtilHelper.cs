﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web.Mvc;

namespace CPFL.COM.Template.Common
{
    public static class UtilHelper
    {
        public static IEnumerable<SelectListItem> GetEnumSelectListItem<T>()
        {
            var itensEnum = GetItens(typeof(T));

            return (from item in itensEnum
                    select new SelectListItem()
                    {
                        Value = item.Key.ToString(),
                        Text = item.Value
                    }).ToList();
        }

        private static Dictionary<int, string> GetItens<T>() where T : struct, IConvertible
        {
            return GetItens(typeof(T));
        }

        private static Dictionary<int, string> GetItens(Type enumType)
        {
            if (!enumType.IsEnum)
            {
                throw new ArgumentException("T must be an enumerated type.");
            }

            Dictionary<int, string> dic = new Dictionary<int, string>();
            string[] names = System.Enum.GetNames(enumType);

            foreach (string item in names)
            {
                System.Enum e = (System.Enum)System.Enum.Parse(enumType, item);
                dic.Add(Convert.ToInt32(e), GetDescription(e));
            }

            return dic;
        }

        private static string GetDescription(System.Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());
            DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);
            return (attributes.Length > 0) ? attributes[0].Description : value.ToString();
        }

        public static string RemoverAcentosEspaco(string str)
        {
            string strsemAcentos = str;

            str = Regex.Replace(str, "[áàâãª]", "a");
            str = Regex.Replace(str, "[ÁÀÂÃ]", "A");
            str = Regex.Replace(str, "[éèê]", "e");
            str = Regex.Replace(str, "[ÉÈÊ]", "e");
            str = Regex.Replace(str, "[íìî]", "i");
            str = Regex.Replace(str, "[ÍÌÎ]", "I");
            str = Regex.Replace(str, "[óòôõº]", "o");
            str = Regex.Replace(str, "[ÓÒÔÕ]", "O");
            str = Regex.Replace(str, "[úùû]", "u");
            str = Regex.Replace(str, "[ÚÙÛ]", "U");
            str = Regex.Replace(str, "[ç]", "c");
            str = Regex.Replace(str, "[Ç]", "C");
            str = Regex.Replace(str, "[Ç]", "C");
            str = Regex.Replace(str, " ", "");
            str = Regex.Replace(str, "_", "");
            str = Regex.Replace(str, "-", "");

            return str;
        }

        public static string FormatFilename(string str, bool arquivoNovo = true)
        {
            if (arquivoNovo)
            {
                Regex regex = new Regex("(\\s\\s+)");
                str = regex.Replace(str, @" ").Replace(" ", "-").Replace("%", "").Replace("&", "");
                return str.ToStringWithoutAccents().ToLower().Substring(0, str.Length - 4) + "_" + DateTime.Now.ToString("yyyy/MM/dd_HH:mm").Replace("-", "_").Replace("'", "").Replace("/", "").Replace(":", "") + str.Substring(str.Length - 4);
            }
            else
            {
                return str.ToStringWithoutAccents().ToLower();
            }
        }

        //public static string FormatFilename(HttpPostedFileBase arquivo)
        //{
        //    var retorno = "";
        //    var extensao = new FileInfo(arquivo.FileName).Extension;

        //    retorno = FormatFilename(arquivo.FileName.Replace(extensao, "").Replace(".", "_") + extensao, true);

        //    return retorno;
        //}

        public static String ToStringWithoutAccents(this Object o, Boolean isSearch = false)
        {
            if (o == null)
                return "";

            String str = o.ToString();

            if (!isSearch)
            {
                str = Regex.Replace(str, "[aáàâãª]", "a");
                str = Regex.Replace(str, "[AÁÀÂÃ]", "A");
                str = Regex.Replace(str, "[eéèê]", "e");
                str = Regex.Replace(str, "[EÉÈÊ]", "E");
                str = Regex.Replace(str, "[iíìî]", "i");
                str = Regex.Replace(str, "[IÍÌÎ]", "I");
                str = Regex.Replace(str, "[oóòôõº]", "o");
                str = Regex.Replace(str, "[OÓÒÔÕ]", "O");
                str = Regex.Replace(str, "[uúùû]", "u");
                str = Regex.Replace(str, "[UÚÙÛ]", "U");
                str = Regex.Replace(str, "[cç]", "c");
                str = Regex.Replace(str, "[CÇ]", "C");
            }
            else
            {
                str = Regex.Replace(str, "[aáàâãª]", "[aáàâãª]");
                str = Regex.Replace(str, "[AÁÀÂÃ]", "[AÁÀÂÃ]");
                str = Regex.Replace(str, "[eéèê]", "[eéèê]");
                str = Regex.Replace(str, "[EÉÈÊ]", "[EÉÈÊ]");
                str = Regex.Replace(str, "[iíìî]", "[iíìî]");
                str = Regex.Replace(str, "[IÍÌÎ]", "[IÍÌÎ]");
                str = Regex.Replace(str, "[oóòôõº]", "[oóòôõº]");
                str = Regex.Replace(str, "[OÓÒÔÕ]", "[OÓÒÔÕ]");
                str = Regex.Replace(str, "[uúùû]", "[uúùû]");
                str = Regex.Replace(str, "[UÚÙÛ]", "[UÚÙÛ]");
                str = Regex.Replace(str, "[cç]", "[cç]");
                str = Regex.Replace(str, "[CÇ]", "[CÇ]");
            }

            return str;
        }

        public static bool IsInternetExplorer(string s)
        {
            if (s.ToUpper().Contains("IE") || s.ToUpper().Contains("INTERNETEXPLORER") || s.ToUpper().Contains("MOZILLA")) //mozilla é referente ao IE11
            {
                return true;
            }

            return false;
        }

        public static void CopyProperties(this object source, object destination)
        {
            // If any this null throw an exception
            if (source == null || destination == null)
                throw new Exception("Source or/and Destination Objects are null");
            // Getting the Types of the objects
            Type typeDest = destination.GetType();
            Type typeSrc = source.GetType();

            // Iterate the Properties of the source instance and  
            // populate them from their desination counterparts  
            PropertyInfo[] srcProps = typeSrc.GetProperties();
            foreach (PropertyInfo srcProp in srcProps)
            {
                if (!srcProp.CanRead)
                {
                    continue;
                }
                PropertyInfo targetProperty = typeDest.GetProperty(srcProp.Name);
                if (targetProperty == null)
                {
                    continue;
                }
                if (!targetProperty.CanWrite)
                {
                    continue;
                }
                if (targetProperty.GetSetMethod(true) != null && targetProperty.GetSetMethod(true).IsPrivate)
                {
                    continue;
                }
                if ((targetProperty.GetSetMethod().Attributes & MethodAttributes.Static) != 0)
                {
                    continue;
                }
                if (!targetProperty.PropertyType.IsAssignableFrom(srcProp.PropertyType))
                {
                    continue;
                }
                // Passed all tests, lets set the value
                targetProperty.SetValue(destination, srcProp.GetValue(source, null), null);
            }
        }
    }
}