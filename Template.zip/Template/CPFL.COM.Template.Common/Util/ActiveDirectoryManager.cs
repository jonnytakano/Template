﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Security.Principal;
using System.Web.Security;

namespace CPFL.CORP.PortalCoordWEB.Common
{
    public class ActiveDirectoryManager
    {
        #region Private Variables

        /// <summary>
        /// AD Host Adress
        /// </summary>
        private string host;

        /// <summary>
        /// Default OU
        /// </summary>
        private string defaultOU;

        #endregion Private Variables

        #region Constructorsf

        /// <summary>
        /// Construtor default
        /// </summary>
        public ActiveDirectoryManager()
        {
            host = ConfigurationManager.AppSettings["ADConnString"];
            defaultOU = ConfigurationManager.AppSettings["DefaultOU"];
        }

        #endregion Constructorsf

        #region Methods

        #region Validate Methods

        /// <summary>
        /// Validates user´s credentials
        /// </summary>
        /// <param name="user"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public bool ValidateCredentials(string user, string password)
        {
            using (PrincipalContext principalContext = GetPrincipalContext())
            {
                return principalContext.ValidateCredentials(user, password);
            }
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public bool UserExists(string user)
        {
            var userExists = false;

            using (PrincipalContext principalContext = GetPrincipalContext())
            {
                using (var userPrincipal = UserPrincipal.FindByIdentity(principalContext, user))
                {
                    userExists = userPrincipal != null;
                }
            }

            return userExists;
        }

        /// <summary>
        /// Checks if user's account expirated
        /// </summary>
        /// <param name="user">User´s login</param>
        /// <returns>Returns True of user's account expirated</returns>
        public bool IsUserExpired(string user)
        {
            using (UserPrincipal userPrincipal = GetUser(user))
            {
                return userPrincipal.AccountExpirationDate != null;
            }
        }

        /// <summary>
        /// Checks if user's account is locked
        /// </summary>
        /// <param name="user">User´s login</param>
        /// <returns>Returns True of user's account is locked</returns>
        public bool IsAccountLocked(string user)
        {
            using (UserPrincipal userPrincipal = GetUser(user))
            {
                return userPrincipal.IsAccountLockedOut();
            }
        }

        /// <summary>
        /// Checks if the user´s account is enabled.
        /// </summary>
        /// <param name="user">User´s login</param>
        /// <returns>Returns True of user's account is enabled</returns>
        public Nullable<bool> Enabled(string user)
        {
            using (UserPrincipal userPrincipal = GetUser(user))
            {
                return userPrincipal.Enabled;
            }
        }

        #endregion Validate Methods

        #region Search Methods

        /// <summary>
        /// Gets Principal Context from AD
        /// </summary>
        /// <returns>Principal Context from AD</returns>
        private PrincipalContext GetPrincipalContext()
        {
            return new PrincipalContext(ContextType.Domain, host, defaultOU);
        }

        /// <summary>
        /// Gets User from AD
        /// </summary>
        /// <param name="user">User´s login</param>
        /// <returns>User from AD</returns>
        public UserPrincipal GetUser(string user)
        {
            UserPrincipal userPrincipal = null;

            using (PrincipalContext principalContext = GetPrincipalContext())
            {
                userPrincipal = UserPrincipal.FindByIdentity(principalContext, user);
            }

            return userPrincipal;
        }

        /// <summary>
        ///  Gets a certain group on Active Directory
        /// </summary>
        /// <param name="groupName">The group to get</param>
        /// <returns>Returns the GroupPrincipal Object</returns>
        public GroupPrincipal GetGroup(string groupName)
        {
            GroupPrincipal groupPrincipal = null;

            using (PrincipalContext principalContext = GetPrincipalContext())
            {
                groupPrincipal = GroupPrincipal.FindByIdentity(principalContext, groupName);
            }

            return groupPrincipal;
        }

        /// <summary>
        /// Checks if user is a member of a given group
        /// </summary>
        /// <param name="groupName">The group you want to check the membership of the user</param>
        /// <param name="user">User´s login</param>
        /// <returns>Returns True if user is a member of a given group</returns>
        public bool IsUserGroupMember(string user, string groupName)
        {
            using (UserPrincipal userPrincipal = GetUser(user))
            {
                using (GroupPrincipal groupPrincipal = GetGroup(groupName))
                {
                    if (userPrincipal == null || groupPrincipal == null)
                    {
                        return groupPrincipal.Members.Contains(userPrincipal);
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }

        /// <summary>
        /// Gets a list of the users group memberships
        /// </summary>
        /// <returns>Returns a list of group memberships</returns>
        public IList<String> GetUserGroups(string user)
        {
            IList<String> items = new List<String>();

            using (UserPrincipal userPrincipal = GetUser(user))
            {
                using (PrincipalSearchResult<Principal> principalSearchResult = userPrincipal.GetGroups())
                {
                    foreach (Principal result in principalSearchResult)
                    {
                        items.Add(result.Name);
                    }
                }
            }

            return items;
        }

        /// <summary>
        ///  Gets a list of the users authorization groups
        /// </summary>
        /// <returns>Returns a list of group authorization memberships</returns>
        public IList<String> GetUserAuthorizationGroups(string user)
        {
            IList<String> items = new List<String>();

            using (UserPrincipal userPrincipal = GetUser(user))
            {
                using (PrincipalSearchResult<Principal> principalSearchResult = userPrincipal.GetAuthorizationGroups())
                {
                    foreach (Principal result in principalSearchResult)
                    {
                        items.Add(result.Name);
                    }
                }
            }

            return items;
        }

        #endregion Search Methods


        #region 
        public bool VerificaUsuarioESenha(string usuario, string senha)
        {
            //mensagemErro = "";
            using (PrincipalContext principalContext = GetPrincipalContext())
            {
                using (var foundUser = UserPrincipal.FindByIdentity(principalContext, IdentityType.SamAccountName, usuario))
                {
                    if (foundUser == null)
                    {
                        //mensagemErro = "Usuário não validado no AD.";
                        //return false;
                        Exception ex = new Exception("Usuário não validado no AD. Nome ou senha estão incorretos!");
                        throw ex;
                    }

                    if (foundUser.IsAccountLockedOut())
                    {
                        Exception ex = new Exception("Sua conta foi bloqueada devido a tentativa de login incorreto.<br /> Solicite o desbloqueio via Portal de Serviços ou 8002.");
                        throw ex;
                    }
                }

                if (!principalContext.ValidateCredentials(usuario, senha))
                {
                    //mensagemErro = "Senha incorreta.";
                    //return false;
                    Exception ex = new Exception("Senha incorreta.");
                    throw ex;
                }

                if (IsUserExpired(usuario))
                {
                    Exception ex = new Exception("Sua conta esta Expirada.");
                    throw ex;
                }



                return true;
            }
        }
        #endregion

        #region Buscar usuario logado no AD
        /// <summary>
        ///    Pesquisar o usuário que está conectado no AD
        /// </summary>
        /// <returns>Retorna a matrícula do usuário que está conectado</returns>
        public UserPrincipal BuscarUsuarioAD(string matricula = "")
        {
            string usuarioLogado = null;
            UserPrincipal userPrincipal = null;

            using (PrincipalContext principalContext = GetPrincipalContext())
            {
                try
                {
                    string usuarioAD = new WindowsPrincipal(WindowsIdentity.GetCurrent()).Identity.Name;
                  

                    if (!String.IsNullOrEmpty(usuarioAD))
                    {
                        if (usuarioAD.Contains('\\'))
                        {
                            var usuario = usuarioAD.Split('\\')[1];
                            usuarioLogado = usuario.ToString();

                            if (!string.IsNullOrEmpty(matricula))
                            {
                                usuarioLogado = matricula;
                            }
                            
                            userPrincipal = new ActiveDirectoryManager().GetUser(usuarioLogado);

                        }
                    }
                }
                catch (Exception e)
                {
                    throw new Exception(e.Message);
                }
            }
            return userPrincipal;
        }

        #endregion

 
    }
    #endregion Methods
}
