﻿using System.Configuration;

namespace CPFL.COM.Template.Common
{
    public static class ConfigDB
    {
        public static readonly string ImagemPathToFormat = ConfigurationManager.AppSettings["_ImagemPathToFormat"];
        public static readonly string ImagemPathEditor = ConfigurationManager.AppSettings["EditorFilePath"];
        public static readonly string URLImageEditor = ConfigurationManager.AppSettings["URLImageEditor"];
    }
}