﻿using System;

namespace CPFL.COM.Template.Common
{
    public class MessageBox
    {
        /// <summary>
        /// Method responsible for showing user's messages
        /// </summary>
        /// <param name="result"></param>
        /// <param name="message">Text to show to user</param>
        /// <param name="messageType">MessageType: Success, Error, Warning and Alert</param>
        /// <param name="link">Url to be sent after OK button</param>
        /// <returns>Object typed as "JSONResult"</returns>
        public static JSONResult ShowMessage(string message, MessageBox.MessageType messageType, string link = "", string contentType = null)
        {
            return ShowMessage(new JSONResult(), message, messageType, link, contentType);
        }

        /// <summary>
		/// Method responsible for showing user's messages
        /// </summary>
		/// <param name="result">JSONResult to be formatted</param>
		/// <param name="message">Text to show to user</param>
		/// <param name="messageType">MessageType: Success, Error, Warning and Alert</param>
		/// <param name="link">Url to be sent after OK button</param>
		/// <returns>Object typed as "JSONResult"</returns> 
        public static JSONResult ShowMessage(JSONResult result, string message, MessageBox.MessageType messageType, string link = "", string contentType = null)
        {
            result.Data = new { _mensagem = message, _tipoMensagem = (int)messageType, _link = link };

            return JSONConvert.Get(result, contentType);
        }

        /// <summary>
        /// Method responsible for showing user's messages
        /// </summary>
        /// <param name="result">JSONResult to be formatted</param>
        /// <param name="ex">Exception to be formatted in an error message</param>				
        public static JSONResult ShowMessage(JSONResult result, Exception ex, string contentType = null)
        {
            JSONResult.Exception(result, ex);

            MessageType tipo;

            if (ex is SuccsessException)
            {
                tipo = MessageType.Success;
            }
            else if (ex is AlertException)
            {
                tipo = MessageType.Warning;
            }
            else if (ex is InfoException)
            {
                tipo = MessageType.Information;
            }
            else
            {
                tipo = MessageType.Error;
            }

            return ShowMessage(result, result.msg, tipo, "", contentType);
        }

        /// <summary>
        /// Method responsible for showing user's messages
        /// </summary>
        /// <param name="ex">Exception to be formatted</param>				
        public static JSONResult ShowMessage(Exception ex, string contentType = null)
        {
            return ShowMessage(new JSONResult(), ex, contentType);
        }

        /// <summary>
		/// Method responsible for showing user's messages
        /// </summary>
		/// <param name="messageType">MessageType: Success, Error, Warning and Alert</param>
        /// <param name="message">Message that will be shown to user</param>
        /// <param name="runFunctionAfter">bool that indicate if a function will run after the OK button</param>
		/// <returns>Object typed as "JSONResult"</returns>    
        public static JSONResult ShowMessage(MessageBox.MessageType messageType, string message, bool runFunctionAfter, string contentType = null)
        {
            return ShowMessage(new JSONResult(), message, messageType, runFunctionAfter, contentType);
        }

        /// <summary>
		/// Method responsible for showing user's messages
        /// </summary>
        /// <param name="result">Json that will be returned</param>
		/// <param name="message">Message that will be shown to user</param>
		/// <param name="messageType">MessageType: Success, Error, Warning and Alert</param>
		/// <param name="runFunctionAfter">bool that indicate if a function will run after the OK button</param>        
		/// <returns>Object typed as "JSONResult"</returns>   
        public static JSONResult ShowMessage(JSONResult result, string message, MessageBox.MessageType messageType, bool runFunctionAfter, string contentType = null)
        {
            result.Data = new { _mensagem = message, _tipoMensagem = (int)messageType, _executaFunction = runFunctionAfter };

            return JSONConvert.Get(result, contentType);
        }

        /// <summary>
        /// MessageType
        /// </summary>
        public enum MessageType
        {
            Success = 1,
            Error = 2,
            Warning = 3,
            Information = 4
        }
    }
}