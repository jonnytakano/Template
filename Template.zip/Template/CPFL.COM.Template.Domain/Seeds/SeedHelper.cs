﻿using CPFL.COM.Template.Domain.Entities;
using System.Collections.Generic;

namespace CPFL.COM.Template.Domain.Seeds
{
    public static class SeedHelper
    {
        public static List<Perfil> GetPerfil()
        {
            var list = new List<Perfil>()
            {
                new Perfil{ Id = 1, Nome = "ADMINISTRADOR" }
            };

            return list;
        }

        public static List<Usuario> GetUsuario()
        {
            var list = new List<Usuario>()
            {
                new Usuario{ Id = 1,IdPerfil = 1, Matricula = "3008638", Nome = "LEANDRO DANILO PIOVEZAN", Email = "ldpiovezan@cpfl.com.br", Empresa = "Authi" }
            };

            return list;
        }

        public static List<Aplicacao> GetAplicacao()
        {
            var list = new List<Aplicacao>()
            {
                new Aplicacao{ Id = 1, IdSubGrupoAplicacao = 1, Controller = "Usuario", Descricao = "Usuário", Rota = "usuario"},
                new Aplicacao{ Id = 2, IdSubGrupoAplicacao = 1, Controller = "Perfil", Descricao = "Perfil", Rota = "perfil"},
                new Aplicacao{ Id = 3, IdSubGrupoAplicacao = 2, Controller = "Logs", Descricao = "Logs", Rota = "Logs"},
            };

            return list;
        }

        public static List<GrupoAplicacao> GetGrupoAplicacao()
        {
            var list = new List<GrupoAplicacao>()
            {
                new GrupoAplicacao{ Id = 1, Descricao = "Configurações", Ordem = 1 , Icone = "Icone-file",   }
            };

            return list;
        }

        public static List<SubGrupoAplicacao> GetSubGrupoAplicacao()
        {
            var list = new List<SubGrupoAplicacao>()
            {
                new SubGrupoAplicacao{ Id = 1, IdGrupoAplicacao = 1, Descricao = "Sistema", Ordem = 1 },
                new SubGrupoAplicacao{ Id = 2, IdGrupoAplicacao = 1, Descricao = "Logs", Ordem = 2 },
            };

            return list;
        }

        public static List<PerfilAplicacao> GetPerfilAplicacao()
        {
            var list = new List<PerfilAplicacao>()
            {
                //ADMINISTRADOR
                new PerfilAplicacao{ Id = 1, IdAplicacao = 1, IdPerfil = 1, Visualizar = true, Excluir = true, Inserir = true, Pesquisar = true, Alterar = true },
                new PerfilAplicacao{ Id = 2, IdAplicacao = 2, IdPerfil = 1, Visualizar = true, Excluir = true, Inserir = true, Pesquisar = true, Alterar = true },
                new PerfilAplicacao{ Id = 3, IdAplicacao = 3, IdPerfil = 1, Visualizar = true, Excluir = true, Inserir = true, Pesquisar = true, Alterar = true },
            };

            return list;
        }



    }
}
