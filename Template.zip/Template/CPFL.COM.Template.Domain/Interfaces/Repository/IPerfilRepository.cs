﻿using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.ViewModel;
using System.Linq;

namespace CPFL.COM.Template.Domain.Interfaces.Repository.Common
{
    public interface IPerfilRepository : IRepository<Perfil>
	{
        IOrderedQueryable<Perfil> Filter(PerfilViewModel entity, int page);
    }
}
