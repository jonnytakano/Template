﻿using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository.Common;

namespace CPFL.COM.Template.Domain.Interfaces.Repository
{
    public interface ISubGrupoAplicacaoRepository : IRepository<SubGrupoAplicacao>
    {
    }
}
