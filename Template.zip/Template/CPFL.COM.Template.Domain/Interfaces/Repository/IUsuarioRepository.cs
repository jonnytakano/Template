﻿using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository.Common;
using CPFL.COM.Template.Domain.ViewModel;
using PagedList;
using System.Linq;

namespace CPFL.COM.Template.Domain.Interfaces.Repository
{
    public interface IUsuarioRepository : IRepository<Usuario>
    {
        Usuario GetByMatricula(string matricula);

        IOrderedQueryable<Usuario> Filter(UsuarioViewModel entity, int page);
    }
}