﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository.Common;

namespace CPFL.COM.Template.Domain.Interfaces.Repository
{
	public interface IPerfilAplicacaoRepository : IRepository<PerfilAplicacao>
	{

	}
}
