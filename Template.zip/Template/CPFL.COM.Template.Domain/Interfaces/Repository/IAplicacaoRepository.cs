﻿using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.Interfaces.Repository.Common;
using System.Collections.Generic;

namespace CPFL.COM.Template.Domain.Interfaces.Repository
{
    public interface IAplicacaoRepository : IRepository<Aplicacao>
    {
        List<Aplicacao> RecuperaNovasAplicacoes(long idPerfil);


    }
}
