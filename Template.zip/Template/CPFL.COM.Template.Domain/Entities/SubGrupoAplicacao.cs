﻿using System.Collections.Generic;

namespace CPFL.COM.Template.Domain.Entities
{
    public class SubGrupoAplicacao
    {
        public SubGrupoAplicacao()
        {
            Ativo = true;
        }

        public long Id { get; set; }
        public long IdGrupoAplicacao { get; set; }
        public string Descricao { get; set; }
        public int Ordem { get; set; }
        public bool Ativo { get; set; }

        public virtual GrupoAplicacao GrupoAplicacao { get; set; }
        public virtual ICollection<Aplicacao> Aplicacao { get; set; }
    }
}