﻿using System.Collections.Generic;

namespace CPFL.COM.Template.Domain.Entities
{
    public class GrupoAplicacao
    {
        public GrupoAplicacao()
        {
            Ativo = true;
        }

        public long Id { get; set; }
        public string Descricao { get; set; }
        public int Ordem { get; set; }
        public string Icone { get; set; }
        public bool Ativo { get; set; }

        public virtual ICollection<SubGrupoAplicacao> SubGrupoAplicacao { get; set; }
    }
}