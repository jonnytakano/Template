﻿using System.Collections.Generic;

namespace CPFL.COM.Template.Domain.Entities
{
    public class Aplicacao
	{
        public Aplicacao()
        {
            Ativo = true;
        }
        
		public long Id { get; set; }
        public long IdSubGrupoAplicacao { get; set; }
        public string Controller { get; set; }
		public string Descricao { get; set; }
		public string Rota { get; set; }
        public bool Ativo { get; set; }

        public virtual SubGrupoAplicacao SubgrupoAplicacao { get; set; }
        public virtual ICollection<PerfilAplicacao> PerfilAplicacao { get; set; }
    }
}