﻿using CPFL.COM.Template.Domain.ViewModel;
using System;
using System.Collections.Generic;

namespace CPFL.COM.Template.Domain.Entities
{
    public class Usuario
    {
        public Usuario()
        {
            Ativo = true;
			DataCadastro = DateTime.Now;
		}

        public long Id { get; set; }
        public long IdPerfil { get; set; }
        public string Nome { get; set; }
        public string Matricula { get; set; }
        public DateTime? UltimoAcesso { get; set; }
        public bool Ativo { get; set; }
		public DateTime DataCadastro { get; set; }
		public string Empresa { get; set; }
		public string Email { get; set; }
		public virtual Perfil Perfil { get; set; }

        public ICollection<LogApp> LogApp { get; set; }

        public static explicit operator Usuario(UsuarioViewModel obj)
        {
			return new Usuario
			{
				Id = obj.Id,
				IdPerfil = obj.IdPerfil,
				Matricula = obj.Matricula,
				Nome = obj.Nome,
				Ativo = obj.Ativo,
				DataCadastro = obj.DataCadastro,
				Empresa = obj.Empresa,
				Email = obj.Email
			};
        }
    }
}