﻿using System;

namespace CPFL.COM.Template.Domain.Entities
{
    public class LogApp
    {
        public LogApp()
        {
            Data = DateTime.Now;
        }

        public long Id { get; set; }
        public string Tabela { get; set; }
        public string Campo { get; set; }
        public string NomePK { get; set; }
        public long ValorPK { get; set; }
        public string ValorAntigo { get; set; }
        public string ValorNovo { get; set; }
        public DateTime Data { get; set; }
        public string ChaveUnica { get; set; }

        public long IdUsuario { get; set; }

        public virtual Usuario Usuario { get; set; }
    }
}