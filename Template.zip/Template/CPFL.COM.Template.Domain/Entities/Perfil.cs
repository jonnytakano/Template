﻿using CPFL.COM.Template.Domain.ViewModel;
using System.Collections.Generic;

namespace CPFL.COM.Template.Domain.Entities
{
	public class Perfil
	{
        public Perfil()
        {
            Ativo = true;
        }

		public long Id { get; set; }
		public string Nome { get; set; }
        public bool Ativo { get; set; }

        public virtual List<Usuario> Usuario  { get; set; }
        
        public virtual ICollection<PerfilAplicacao> PerfilAplicacao { get; set; }

        public static explicit operator Perfil(PerfilViewModel obj)
        {
            var @return = new Perfil
            {
                Id = obj.Id,
                Nome = obj.Nome,
                Ativo = obj.Ativo
            };

            @return.PerfilAplicacao = new List<PerfilAplicacao>(); 

            obj.PerfilAplicacao.ForEach(c => @return.PerfilAplicacao.Add((PerfilAplicacao)c));

            return @return;
        }
    }
}