﻿using System.ComponentModel;

namespace CPFL.COM.Template.Domain.Enuns
{
    public enum eUsuario
    {
        Administrador = 1
    }

    public enum ePerfil
    {
        Administrador = 1,
    }

    public enum eIcone
    {
        [Description("icon-desktop")]
        icon_desktop = 1,

        [Description("icon-book")]
        icon_book = 2,

        [Description("icon-briefcase")]
        icon_briefcase = 3,

        [Description("icon-asterisk")]
        icon_asterisk = 4,

        [Description("icon-lock")]
        icon_lock = 5,

        [Description("icon-bar-chart")]
        icon_bar_chart = 6,

        [Description("icon-gear")]
        icon_gear = 7,

        [Description("icon-pencil")]
        icon_pencil = 8,

        [Description("icon-dashboard")]
        icon_dashboard = 9,

        [Description("icon-picture")]
        icon_picture = 10,

        [Description("icon-question")]
        icon_question = 11,

        [Description("icon-bank")]
        icon_bank = 12,

        [Description("icon-envelope")]
        icon_envelope = 13,

        [Description("icon-newspaper-o")]
        icon_newspaper = 14,

        [Description("icon-male")]
        icon_male = 15

    }

    public enum eMeioComunicacao
    {
        [Description("Telefone residencial")]
        TelefoneResidencial = 1,

        [Description("Telefone comercial")]
        TelefoneComercial = 2,

        [Description("Telefone celular")]
        TelefoneCelular = 3,

        [Description("E-mail")]
        Email = 4,

        [Description("Telefone Fax")]
        TelefoneFax = 5
    }

    public enum eStatusAcesso
    {
        [Description("Permitido")]
        Permitido = 1,
        [Description("Bloqueado")]
        Bloqueado = 2,
        [Description("Vencido")]
        Vencido = 3,
        [Description("Cancelado")]
        Cancelado = 4
    }

    public enum eGenero
    {
        [Description("Masculino")]
        Masculino = 1,
        [Description("Feminino")]
        Feminino = 2
    }
}
