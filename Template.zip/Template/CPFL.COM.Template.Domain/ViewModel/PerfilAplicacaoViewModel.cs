﻿using CPFL.COM.Template.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPFL.COM.Template.Domain.ViewModel
{
    public class PerfilAplicacaoViewModel
    {
        public long Id { get; set; }
        public long IdAplicacao { get; set; }
        public long IdPerfil { get; set; }

        public string Aplicacao { get; set; }

        public bool Inserir { get; set; }
        public bool Alterar { get; set; }
        public bool Excluir { get; set; }
        public bool Visualizar { get; set; }
        public bool Pesquisar { get; set; }
        public bool Exportar { get; set; }

        public static explicit operator PerfilAplicacaoViewModel(PerfilAplicacao obj)
        {
            var @return = new PerfilAplicacaoViewModel
            {
                Alterar = obj.Alterar,
                Excluir = obj.Excluir,
                Exportar = obj.Exportar,
                Id = obj.Id,
                IdAplicacao = obj.IdAplicacao,
                IdPerfil = obj.IdPerfil,
                Inserir = obj.Inserir,
                Pesquisar = obj.Pesquisar,
                Visualizar = obj.Visualizar,
                Aplicacao = obj.Aplicacao.Descricao
            };

            return @return;
        }
    }
}
