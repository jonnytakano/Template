﻿using CPFL.COM.Template.Domain.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPFL.COM.Template.Domain.ViewModel
{
    public class PerfilViewModel
    {
        public PerfilViewModel()
        {
            PerfilAplicacao = new List<PerfilAplicacaoViewModel>();
        }

        #region [  Filter  ]
        
        public string FiltroNome { get; set; }
        public bool FiltroAtivo { get; set; }

        #endregion

        public long Id { get; set; }

        [Required]
        public string Nome { get; set; }

        [Required]
        public bool Ativo { get; set; }

        public List<PerfilAplicacaoViewModel> PerfilAplicacao { get; set; }

        public static explicit operator PerfilViewModel(Perfil obj)
        {
            var @return = new PerfilViewModel
            {
                Id = obj.Id,
                Nome = obj.Nome,
                Ativo = obj.Ativo
            };

            @return.PerfilAplicacao = new List<PerfilAplicacaoViewModel>();

            obj.PerfilAplicacao.ToList().ForEach(c => @return.PerfilAplicacao.Add((PerfilAplicacaoViewModel)c));

            return @return;
        }
    }
}
