﻿using System.ComponentModel.DataAnnotations;

namespace CPFL.COM.Template.Domain.ViewModel
{
    public class LoginViewModel
    {        
        [Display(Name = "Matrícula")]
        public string Login { get; set; }

        [Display(Name = "Senha")]
        public string Senha { get; set; }

        public long Perfil { get; set; }
    }
}
