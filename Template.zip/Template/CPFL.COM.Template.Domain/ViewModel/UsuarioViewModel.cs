﻿using CPFL.COM.Template.Domain.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CPFL.COM.Template.Domain.ViewModel
{
    public class UsuarioViewModel
    {
        public UsuarioViewModel()
        {
            PerfilItens = new List<SelectListItem>();
            Ativo = true;
            DataCadastro = DateTime.Now;
        }

        #region [  Filter  ]

        public string FiltroMatricula { get; set; }

        public string FiltroNome { get; set; }

        public bool FiltroAtivo { get; set; }

        #endregion

        public bool _Pesquisado { get; set; }

        public long Id { get; set; }
        
        [Required]
        [Range(1, long.MaxValue)]
        [Display(Name = "Perfil")]
        public long IdPerfil { get; set; }

        [Required]
        public string Nome { get; set; }

        [Required]
        public string Matricula { get; set; }

        public bool Ativo { get; set; }

        public DateTime DataCadastro { get; set; }

        public string Empresa { get; set; }

        [Required]
        [Display(Name = "E-mail")]
        public string Email { get; set; }

        public List<SelectListItem> PerfilItens { get; set; }

        public static explicit operator UsuarioViewModel(Usuario obj)
        {
            return new UsuarioViewModel
            {
                Id = obj.Id,
                IdPerfil = obj.IdPerfil,
                Matricula = obj.Matricula,
                Nome = obj.Nome,
                Ativo = obj.Ativo,
                DataCadastro = obj.DataCadastro,
                Empresa = obj.Empresa,
                Email = obj.Email
            };
        }

    }
}
