﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using CPFL.COM.Template.Domain.Entities;

namespace CPFL.COM.Template.Data.Context.Mapping
{
	public class UsuarioMap : EntityTypeConfiguration<Usuario>
    {
        public UsuarioMap()
        {
            //PK
            HasKey(c => c.Id);

            //IDENTITY
            Property(c => c.Id)
                    .IsRequired()
                    .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(c => c.IdPerfil)
                   .IsRequired();

            Property(c => c.Nome)
                    .IsRequired()
                    .HasMaxLength(100);

			Property(c => c.Matricula)
					.IsRequired()
					.HasMaxLength(100);

			Property(c => c.UltimoAcesso)
					.IsOptional();

			Property(c => c.Ativo)
                    .IsRequired();

			Property(c => c.DataCadastro)
					.IsRequired();

			Property(c => c.Empresa)
					.IsRequired();

			Property(c => c.Email)
					.IsRequired()
					.HasMaxLength(100);

			//RELATIONS 
			HasRequired(c => c.Perfil)
				.WithMany(c => c.Usuario)
				.HasForeignKey(c => c.IdPerfil)
				.WillCascadeOnDelete(false);

            HasMany(c => c.LogApp)
                    .WithRequired(c => c.Usuario)
                    .WillCascadeOnDelete(false);
        }
    }
}