﻿using CPFL.COM.Template.Domain.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace CPFL.COM.Template.Data.Context.Mapping
{
    public class LogAppMap : EntityTypeConfiguration<LogApp>
    {
        public LogAppMap()
        {
            //PK
            HasKey(c => c.Id);

            //PROPERTIES
            Property(c => c.Id)
                .IsRequired()
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(c => c.Tabela)
                .IsRequired()
                .HasMaxLength(100);

            Property(c => c.Campo)
                .IsRequired()
                .HasMaxLength(100);

            Property(c => c.NomePK)
                .IsRequired()
                .HasMaxLength(100);

            Property(c => c.ValorPK)
                .IsRequired();

            Property(c => c.ValorAntigo)
                .HasColumnType("text")
                .IsOptional();

            Property(c => c.ValorNovo)
                .HasColumnType("text")
                .IsOptional();

            Property(c => c.Data)
                .IsRequired();

            Property(c => c.IdUsuario)
                .IsRequired();

            Property(c => c.ChaveUnica)
                .IsRequired()
                .HasMaxLength(150);

            //RELATIONS 
            HasRequired(c => c.Usuario)
                .WithMany(c => c.LogApp)
                .HasForeignKey(c => c.IdUsuario)
                .WillCascadeOnDelete(false);
        }
    }
}