﻿using CPFL.COM.Template.Domain.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace CPFL.COM.Template.Data.Context.Mapping
{
    public class GrupoAplicacaoMap : EntityTypeConfiguration<GrupoAplicacao>
    {

        public GrupoAplicacaoMap()
        {
            //PK
            HasKey(c => c.Id);

            //Identity
            Property(c => c.Id)
                    .IsRequired()
                    .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(c => c.Descricao)
                   .IsRequired()
                   .HasMaxLength(500);

            Property(c => c.Ordem)
                  .IsRequired();

            Property(c => c.Icone)
                    .IsRequired()
                    .HasMaxLength(500);

            Property(c => c.Ativo)
                  .IsRequired();

            //RELATIONS 
            HasMany(c => c.SubGrupoAplicacao)
                    .WithRequired(c => c.GrupoAplicacao)
                    .WillCascadeOnDelete(false);

        }

    }
}
