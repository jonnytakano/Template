﻿using CPFL.COM.Template.Domain.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace CPFL.COM.Template.Data.Context.Mapping
{
    public class SubGrupoAplicacaoMap : EntityTypeConfiguration<SubGrupoAplicacao>
    {

        public SubGrupoAplicacaoMap()

        {
            //PK
            HasKey(c => c.Id);

            //IDENTITY
            Property(c => c.Id)
                    .IsRequired()
                    .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(c => c.IdGrupoAplicacao)
                    .IsRequired();

            Property(c => c.Descricao)
                    .IsRequired()
                    .HasMaxLength(500);

            Property(c => c.Ordem)
                .IsRequired();

            Property(c => c.Ativo)
                    .IsRequired();

            //RELATIONS
            HasRequired(c => c.GrupoAplicacao)
                .WithMany(c => c.SubGrupoAplicacao)
                .HasForeignKey(c => c.IdGrupoAplicacao)
                .WillCascadeOnDelete(false);

            HasMany(c => c.Aplicacao)
                    .WithRequired(c => c.SubgrupoAplicacao)
                    .WillCascadeOnDelete(false);
        }
    }
}