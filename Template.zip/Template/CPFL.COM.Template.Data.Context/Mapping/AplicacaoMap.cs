﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using CPFL.COM.Template.Domain.Entities;


namespace CPFL.COM.Template.Data.Context.Mapping
{
    public class AplicacaoMap : EntityTypeConfiguration<Aplicacao>
    {

        public AplicacaoMap()
        {
            //PK
            HasKey(c => c.Id);

            //Identity
            Property(c => c.Id)
                    .IsRequired()
                    .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(c => c.IdSubGrupoAplicacao)
                  .IsRequired();

            Property(c => c.Controller)
                    .IsRequired()
                    .HasMaxLength(500);            

            Property(c => c.Descricao)
                   .IsRequired()
                   .HasMaxLength(500);

            Property(c => c.Rota)
                   .IsRequired()
                   .HasMaxLength(500);

            Property(c => c.Ativo)
                    .IsRequired();

            //RELATIONS   
            HasMany(c => c.PerfilAplicacao)
                .WithRequired(c => c.Aplicacao)
                .WillCascadeOnDelete(false);

            HasRequired(c => c.SubgrupoAplicacao)
              .WithMany(c => c.Aplicacao)
              .HasForeignKey(c => c.IdSubGrupoAplicacao)
              .WillCascadeOnDelete(false);


        }

    }
}
