﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using CPFL.COM.Template.Domain.Entities;

namespace CPFL.COM.Template.Data.Context.Mapping
{
	public class PerfilMap : EntityTypeConfiguration<Perfil>
	{
		public PerfilMap()
		{
            //PK
			HasKey(c => c.Id);

            //Identity
			Property(c => c.Id)
					.IsRequired()
					.HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

			Property(c => c.Nome)
					.IsRequired()
					.HasMaxLength(100);

            Property(c => c.Ativo)
                    .IsRequired();

            //RELATIONS
            HasMany(c => c.Usuario)
                    .WithRequired(c => c.Perfil)
                    .WillCascadeOnDelete(false);
        }
	}
}