﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using CPFL.COM.Template.Domain.Entities;

namespace CPFL.COM.Template.Data.Context.Mapping
{
    public class PerfilAplicacaoMap : EntityTypeConfiguration<PerfilAplicacao>
    {
        public PerfilAplicacaoMap()
        {
            //PK
            HasKey(c => c.Id);

            //IDENTITY
            Property(c => c.Id)
                    .IsRequired()
                    .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(c => c.IdPerfil)
                    .IsRequired();

            Property(c => c.IdAplicacao)
                    .IsRequired();

            Property(c => c.Visualizar)
                    .IsRequired();

            Property(c => c.Inserir)
                    .IsRequired();

            Property(c => c.Alterar)
                    .IsRequired();

            Property(c => c.Excluir)
                    .IsRequired();

            Property(c => c.Pesquisar)
                    .IsRequired();

            Property(c => c.Exportar)
                    .IsRequired();

            Property(c => c.Ativo)
                    .IsRequired();

            //RELATIONS
            HasRequired(c => c.Aplicacao)
                .WithMany(c => c.PerfilAplicacao)
                .HasForeignKey(c => c.IdAplicacao)
                .WillCascadeOnDelete(false);

            HasRequired(c => c.Perfil)
               .WithMany(c => c.PerfilAplicacao)
               .HasForeignKey(c => c.IdPerfil)
               .WillCascadeOnDelete(false);
        }
    }
}