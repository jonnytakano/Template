﻿using CPFL.COM.Template.Data.Context.Config;
using CPFL.COM.Template.Data.Context.Logging;
using CPFL.COM.Template.Data.Context.Mapping;
using CPFL.COM.Template.Data.Context.Migrations;
using CPFL.COM.Template.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Migrations;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;

namespace CPFL.COM.Template.Data.Context
{
    public class DatabaseContext : BaseDbContext
    {
        public DatabaseContext()
            : base("DatabaseContext")
        {
            Configuration.LazyLoadingEnabled = true;
        }

        public void Update()
        {
            var migratorConfig = new Configuration();
            var dbMigrator = new DbMigrator(migratorConfig);

            if (dbMigrator.GetPendingMigrations().Any())
            {
                dbMigrator.Update();
            }
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            modelBuilder.Properties<string>().Configure(c => c.IsUnicode(false));

            base.OnModelCreating(modelBuilder);

            modelBuilder.Configurations.Add(new LogAppMap());
            modelBuilder.Configurations.Add(new UsuarioMap());
            modelBuilder.Configurations.Add(new PerfilMap());
            modelBuilder.Configurations.Add(new AplicacaoMap());
            modelBuilder.Configurations.Add(new GrupoAplicacaoMap());
            modelBuilder.Configurations.Add(new PerfilAplicacaoMap());
            modelBuilder.Configurations.Add(new SubGrupoAplicacaoMap());
        }

        #region [  DbSet  ]

        public DbSet<LogApp> LogApp { get; set; }
        public DbSet<Usuario> Usuario { get; set; }
        public DbSet<Perfil> Perfil { get; set; }
        public DbSet<Aplicacao> Aplicacao { get; set; }
        public DbSet<GrupoAplicacao> GrupoAplicacao { get; set; }
        public DbSet<PerfilAplicacao> PerfilAplicacao { get; set; }
        public DbSet<SubGrupoAplicacao> SubGrupoAplicacao { get; set; }


        #endregion

        #region [  EF Overrides  ]

        public int SaveChanges(SaveOptions options)
        {
            return ((IObjectContextAdapter)this).ObjectContext.SaveChanges(options);
        }

        public void AcceptAllChanges()
        {
            ((IObjectContextAdapter)this).ObjectContext.AcceptAllChanges();
        }

        object GetPrimaryKeyValue(DbEntityEntry entry, ref string pkName)
        {
            var objectStateEntry = ((IObjectContextAdapter)this).ObjectContext.ObjectStateManager.GetObjectStateEntry(entry.Entity);
            var objPK = objectStateEntry.EntityKey.EntityKeyValues[0];

            if (objPK != null)
            {
                pkName = objPK.Key;
                return objPK.Value;
            }

            return 0;
        }

        #endregion

        public override int SaveChanges()
        {
            //Inicializa com "-1" linhas afetadas
            var i = -1;

            //Recupera quais tabelas terão LOG
            var tablesToLog = LoggingHelper.GetTablesToLog();
            var itensLog = new List<LogApp>();
            //Gera uma chave para identificar todos os registros alterados de uma única vez
            var ChaveUnica = Convert.ToString(Guid.NewGuid());


            try
            {
                #region [  Modify  ]

                var modifiedEntities = ChangeTracker.Entries()
                .Where(p => p.State == EntityState.Modified)
                .ToList();
                var now = DateTime.UtcNow;

                foreach (var change in modifiedEntities)
                {
                    var entityName = change.Entity.GetType().BaseType.Name;

                    //Valida se deve fazer LOG deste objeto (Tabela)
                    if (!tablesToLog.Contains(entityName.ToUpper())) { continue; }

                    switch (change.State)
                    {
                        case EntityState.Modified:
                            var pkName = "";
                            var primaryKey = GetPrimaryKeyValue(change, ref pkName);
                            var originalValues = change.GetDatabaseValues();

                            foreach (var prop in change.OriginalValues.PropertyNames)
                            {
                                var originalValue = Convert.ToString(originalValues[prop] ?? "");
                                var currentValue = Convert.ToString(change.CurrentValues[prop] ?? "");

                                if (originalValue != currentValue)
                                {
                                    itensLog.Add(new LogApp
                                    {
                                        Tabela = entityName,
                                        NomePK = pkName,
                                        ValorPK = Convert.ToInt64(primaryKey),
                                        Campo = prop,
                                        ValorAntigo = originalValue,
                                        ValorNovo = currentValue,
                                        ChaveUnica = ChaveUnica,
                                        IdUsuario = (System.Web.HttpContext.Current.User.Identity.IsAuthenticated ? Convert.ToInt64(System.Web.HttpContext.Current.User.Identity.Name) : 1)//((Usuario)System.Web.HttpContext.Current.Session["Sessao.Usuario"]).Id,
                                    });

                                }
                            }
                            break;
                        default:
                            break;
                    }
                }

                #endregion

                #region [  Add / Delete  ]

                //Identifica as alterações
                base.ChangeTracker.DetectChanges();
                ObjectContext context = ((IObjectContextAdapter)this).ObjectContext;
                var objectStateEntryList = context.ObjectStateManager.GetObjectStateEntries(EntityState.Added | EntityState.Deleted);

                i = this.SaveChanges(SaveOptions.None);

                foreach (ObjectStateEntry entry in objectStateEntryList)
                {
                    //Somente faz log de objetos vinculados ao Context
                    if (entry.State != EntityState.Detached)
                    {
                        //Valida se deve fazer LOG deste objeto (Tabela)
                        if (!tablesToLog.Contains(entry.EntitySet.Name.ToUpper())) { continue; }

                        if (!entry.IsRelationship)
                        {
                            //Recupera valor da PK da tabela
                            var nome_pk = entry.EntitySet.ElementType.KeyMembers[0].Name;
                            var valor_pk = entry.Entity.GetType().GetProperty(nome_pk.ToString()).GetValue(entry.Entity, null);

                            //Para cada "status", efetua o LOG
                            switch (entry.State)
                            {
                                case EntityState.Added:
                                    foreach (var item in entry.Entity.GetType().GetProperties())
                                    {
                                        try
                                        {
                                            itensLog.Add(new LogApp
                                            {
                                                Tabela = entry.EntitySet.Name,
                                                NomePK = nome_pk,
                                                ValorPK = Convert.ToInt64(valor_pk),
                                                Campo = item.Name,
                                                ValorAntigo = null,
                                                ValorNovo = Convert.ToString(entry.CurrentValues[item.Name]),
                                                ChaveUnica = ChaveUnica,
                                                IdUsuario = (System.Web.HttpContext.Current.User.Identity.IsAuthenticated ? Convert.ToInt64(System.Web.HttpContext.Current.User.Identity.Name) : 1)//((Usuario)System.Web.HttpContext.Current.Session["Sessao.Usuario"]).Id,
                                            });
                                        }
                                        catch { }
                                    }
                                    break;
                                case EntityState.Deleted:
                                    foreach (var item in entry.Entity.GetType().GetProperties())
                                    {
                                        try
                                        {
                                            itensLog.Add(new LogApp
                                            {
                                                Tabela = entry.EntitySet.Name,
                                                NomePK = nome_pk,
                                                ValorPK = Convert.ToInt64(valor_pk),
                                                Campo = item.Name,
                                                ValorAntigo = Convert.ToString(entry.OriginalValues[item.Name]),
                                                ValorNovo = null,
                                                ChaveUnica = ChaveUnica,
                                                IdUsuario = (System.Web.HttpContext.Current.User.Identity.IsAuthenticated ? Convert.ToInt64(System.Web.HttpContext.Current.User.Identity.Name) : 1)//((Usuario)System.Web.HttpContext.Current.Session["Sessao.Usuario"]).Id,
                                            });
                                        }
                                        catch { }
                                    }
                                    break;
                                case EntityState.Modified:
                                    {
                                        foreach (string item in entry.GetModifiedProperties())
                                        {
                                            DbDataRecord original = entry.OriginalValues;
                                            string oldValue = original.GetValue(original.GetOrdinal(item)).ToString();

                                            CurrentValueRecord current = entry.CurrentValues;
                                            string newValue = current.GetValue(current.GetOrdinal(item)).ToString();

                                            if (oldValue != newValue)
                                            {
                                                try
                                                {
                                                    itensLog.Add(new LogApp
                                                    {
                                                        Tabela = entry.EntitySet.Name,
                                                        NomePK = nome_pk,
                                                        ValorPK = Convert.ToInt64(valor_pk),
                                                        Campo = item,
                                                        ValorAntigo = oldValue,
                                                        ValorNovo = newValue,
                                                        ChaveUnica = ChaveUnica,
                                                        IdUsuario = (System.Web.HttpContext.Current.User.Identity.IsAuthenticated ? Convert.ToInt64(System.Web.HttpContext.Current.User.Identity.Name) : 1)//((Usuario)System.Web.HttpContext.Current.Session["Sessao.Usuario"]).Id,
                                                    });
                                                }
                                                catch { }
                                            }
                                        }
                                        break;
                                    }
                            }

                            //Salve LOG no banco e aceita mudanças no Context
                            SaveLOG(itensLog);
                            itensLog = new List<LogApp>();
                            this.AcceptAllChanges();
                        }
                    }
                }

                if (itensLog.Count > 0)
                {
                    SaveLOG(itensLog);
                }

                #endregion
            }
            catch { throw; }

            return i;
        }

        private void SaveLOG(List<LogApp> listLog)
        {
            try
            {
                var db = new DatabaseContext();
                db.Configuration.AutoDetectChangesEnabled = false;

                foreach (var item in listLog)
                {
                    db.LogApp.Add(item);
                }

                db.SaveChanges();
            }
            catch (Exception ex) { }
        }




    }
}