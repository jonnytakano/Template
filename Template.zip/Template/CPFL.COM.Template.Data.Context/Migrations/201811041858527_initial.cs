namespace CPFL.COM.Template.Data.Context.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Aplicacao",
                c => new
                    {
                        Id = c.Long(nullable: false, identity: true),
                        IdSubGrupoAplicacao = c.Long(nullable: false),
                        Controller = c.String(nullable: false, maxLength: 500, unicode: false),
                        Descricao = c.String(nullable: false, maxLength: 500, unicode: false),
                        Rota = c.String(nullable: false, maxLength: 500, unicode: false),
                        Ativo = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.SubGrupoAplicacao", t => t.IdSubGrupoAplicacao)
                .Index(t => t.IdSubGrupoAplicacao);
            
            CreateTable(
                "dbo.PerfilAplicacao",
                c => new
                    {
                        Id = c.Long(nullable: false, identity: true),
                        IdPerfil = c.Long(nullable: false),
                        IdAplicacao = c.Long(nullable: false),
                        Visualizar = c.Boolean(nullable: false),
                        Inserir = c.Boolean(nullable: false),
                        Alterar = c.Boolean(nullable: false),
                        Excluir = c.Boolean(nullable: false),
                        Pesquisar = c.Boolean(nullable: false),
                        Exportar = c.Boolean(nullable: false),
                        Ativo = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Perfil", t => t.IdPerfil)
                .ForeignKey("dbo.Aplicacao", t => t.IdAplicacao)
                .Index(t => t.IdPerfil)
                .Index(t => t.IdAplicacao);
            
            CreateTable(
                "dbo.Perfil",
                c => new
                    {
                        Id = c.Long(nullable: false, identity: true),
                        Nome = c.String(nullable: false, maxLength: 100, unicode: false),
                        Ativo = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Usuario",
                c => new
                    {
                        Id = c.Long(nullable: false, identity: true),
                        IdPerfil = c.Long(nullable: false),
                        Nome = c.String(nullable: false, maxLength: 100, unicode: false),
                        Matricula = c.String(nullable: false, maxLength: 100, unicode: false),
                        UltimoAcesso = c.DateTime(),
                        Ativo = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Perfil", t => t.IdPerfil)
                .Index(t => t.IdPerfil);
            
            CreateTable(
                "dbo.LogApp",
                c => new
                    {
                        Id = c.Long(nullable: false, identity: true),
                        Tabela = c.String(nullable: false, maxLength: 100, unicode: false),
                        Campo = c.String(nullable: false, maxLength: 100, unicode: false),
                        NomePK = c.String(nullable: false, maxLength: 100, unicode: false),
                        ValorPK = c.Long(nullable: false),
                        ValorAntigo = c.String(unicode: false, storeType: "text"),
                        ValorNovo = c.String(unicode: false, storeType: "text"),
                        Data = c.DateTime(nullable: false),
                        ChaveUnica = c.String(nullable: false, maxLength: 150, unicode: false),
                        IdUsuario = c.Long(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Usuario", t => t.IdUsuario)
                .Index(t => t.IdUsuario);
            
            CreateTable(
                "dbo.SubGrupoAplicacao",
                c => new
                    {
                        Id = c.Long(nullable: false, identity: true),
                        IdGrupoAplicacao = c.Long(nullable: false),
                        Descricao = c.String(nullable: false, maxLength: 500, unicode: false),
                        Ordem = c.Int(nullable: false),
                        Ativo = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.GrupoAplicacao", t => t.IdGrupoAplicacao)
                .Index(t => t.IdGrupoAplicacao);
            
            CreateTable(
                "dbo.GrupoAplicacao",
                c => new
                    {
                        Id = c.Long(nullable: false, identity: true),
                        Descricao = c.String(nullable: false, maxLength: 500, unicode: false),
                        Ordem = c.Int(nullable: false),
                        Icone = c.String(nullable: false, maxLength: 500, unicode: false),
                        Ativo = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Aplicacao", "IdSubGrupoAplicacao", "dbo.SubGrupoAplicacao");
            DropForeignKey("dbo.SubGrupoAplicacao", "IdGrupoAplicacao", "dbo.GrupoAplicacao");
            DropForeignKey("dbo.PerfilAplicacao", "IdAplicacao", "dbo.Aplicacao");
            DropForeignKey("dbo.PerfilAplicacao", "IdPerfil", "dbo.Perfil");
            DropForeignKey("dbo.Usuario", "IdPerfil", "dbo.Perfil");
            DropForeignKey("dbo.LogApp", "IdUsuario", "dbo.Usuario");
            DropIndex("dbo.SubGrupoAplicacao", new[] { "IdGrupoAplicacao" });
            DropIndex("dbo.LogApp", new[] { "IdUsuario" });
            DropIndex("dbo.Usuario", new[] { "IdPerfil" });
            DropIndex("dbo.PerfilAplicacao", new[] { "IdAplicacao" });
            DropIndex("dbo.PerfilAplicacao", new[] { "IdPerfil" });
            DropIndex("dbo.Aplicacao", new[] { "IdSubGrupoAplicacao" });
            DropTable("dbo.GrupoAplicacao");
            DropTable("dbo.SubGrupoAplicacao");
            DropTable("dbo.LogApp");
            DropTable("dbo.Usuario");
            DropTable("dbo.Perfil");
            DropTable("dbo.PerfilAplicacao");
            DropTable("dbo.Aplicacao");
        }
    }
}
