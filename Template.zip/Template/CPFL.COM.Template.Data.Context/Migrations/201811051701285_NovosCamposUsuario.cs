namespace CPFL.COM.Template.Data.Context.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class NovosCamposUsuario : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Usuario", "DataCadastro", c => c.DateTime(nullable: false));
            AddColumn("dbo.Usuario", "Empresa", c => c.String(nullable: false, unicode: false));
            AddColumn("dbo.Usuario", "Email", c => c.String(nullable: false, maxLength: 100, unicode: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Usuario", "Email");
            DropColumn("dbo.Usuario", "Empresa");
            DropColumn("dbo.Usuario", "DataCadastro");
        }
    }
}
