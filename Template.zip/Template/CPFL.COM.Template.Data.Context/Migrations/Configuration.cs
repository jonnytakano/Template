namespace CPFL.COM.Template.Data.Context.Migrations
{
    using CPFL.COM.Template.Domain.Seeds;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    public sealed class Configuration : DbMigrationsConfiguration<CPFL.COM.Template.Data.Context.DatabaseContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(CPFL.COM.Template.Data.Context.DatabaseContext context)
        {
            if (context.Usuario.Find(1) == null)
            {
                SeedHelper.GetUsuario().ForEach(c => context.Usuario.AddOrUpdate(c));
            }

            SeedHelper.GetPerfil().ForEach(c => context.Perfil.AddOrUpdate(c));

            SeedHelper.GetGrupoAplicacao().ForEach(c => context.GrupoAplicacao.AddOrUpdate(c));
            SeedHelper.GetSubGrupoAplicacao().ForEach(c => context.SubGrupoAplicacao.AddOrUpdate(c));
            SeedHelper.GetAplicacao().ForEach(c => context.Aplicacao.AddOrUpdate(c));
            SeedHelper.GetPerfilAplicacao().ForEach(c => context.PerfilAplicacao.AddOrUpdate(c));

        }
    }
}
