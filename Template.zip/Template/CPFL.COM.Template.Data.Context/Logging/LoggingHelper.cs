﻿using System.Collections.Generic;

namespace CPFL.COM.Template.Data.Context.Logging
{
    public static class LoggingHelper
    {
        public static List<string> GetTablesToLog()
        {
            var tablesToLog = new List<string>();

            //TODO: Tabelas que estarão no LOG! SEMPRE CONFIGURAR!
            tablesToLog.Add("USUARIO");
            tablesToLog.Add("PERFIL");
            tablesToLog.Add("PERFILAPLICACAO");
            tablesToLog.Add("APLICACAO");

            return tablesToLog;
        }
    }
}
