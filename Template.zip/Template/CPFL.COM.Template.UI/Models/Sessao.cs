﻿using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Service;
using CPFL.COM.Template.Service.Interfaces;
using Microsoft.Practices.ServiceLocation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

namespace CPFL.COM.Template.UI.Models
{
    public class Sessao
    {
        private const string UsuarioSessionName = "Sessao.Usuario";
        private const string PerfilSessionName = "Sessao.Perfil";
        private const string PerfilAplicacaoSessionName = "Sessao.Aplicacao";

        private static HttpSessionState Session { get { return HttpContext.Current.Session; } }
        private static HttpRequest Request { get { return HttpContext.Current.Request; } }

        private static IUsuarioService _UsuarioService
        {
            get { return ServiceLocator.Current.GetInstance<IUsuarioService>(); }
        }

        private static void DoLogin()
        {
            var idUsuario = HttpContext.Current.User.Identity.Name.ToInt64();

            var usuario = _UsuarioService.Get(idUsuario);

            if (usuario != null)
            {
                Login(usuario);
            }
            else
            {
                Logout();
                FormsAuthentication.RedirectToLoginPage();
            }
        }

        public static string Login(Usuario usuario)
        {
            string cookie;

            if (!usuario.IsNull())
            {
                Usuario = usuario;
                Aplicacao = usuario.Perfil.PerfilAplicacao.Where(q => q.Ativo).ToList();

                cookie = String.Format("{0}", usuario.Id);

                FormsAuthentication.SetAuthCookie(cookie, false);
            }
            else
            {
                return Logout();
            }

            string link = FormsAuthentication.GetRedirectUrl(cookie, false);

            if (link.IsNullOrWhiteSpace())
            {
                link = FormsAuthentication.DefaultUrl;
            }

            return link;
        }

        public static string Logout()
        {
            Session.Abandon();
            Session.Clear();
            Session.RemoveAll();

            FormsAuthentication.SignOut();

            return FormsAuthentication.LoginUrl;
        }

        public static Usuario Usuario
        {
            get
            {
                if (Session[UsuarioSessionName] == null && HttpContext.Current.User.Identity.IsAuthenticated)
                {
                    DoLogin();
                }

                return (Usuario)Session[UsuarioSessionName];
            }
            set
            {
                Session[UsuarioSessionName] = value;
            }

        }
        public static List<PerfilAplicacao> Aplicacao
        {
            get
            {
                if (Session[PerfilAplicacaoSessionName] == null && HttpContext.Current.User.Identity.IsAuthenticated)
                {
                    DoLogin();
                }

                return (List<PerfilAplicacao>)Session[PerfilAplicacaoSessionName];
            }
            set
            {
                Session[PerfilAplicacaoSessionName] = value;
            }

        }
    }
}