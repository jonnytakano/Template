﻿using CPFL.COM.Template.Data.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Text;

namespace CPFL.COM.Template.UI
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            new DatabaseContext().Update();
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            var exception = Server.GetLastError();
            if (exception == null)
                return;

            var code = (exception is HttpException) ? (exception as HttpException).GetHttpCode() : 500;

            if (code != 404)
            {
                var sbCorpoEmail = new StringBuilder();

                var Data = DateTime.UtcNow;
                var Descricao = exception.Message + (exception.InnerException != null ? exception.InnerException : new Exception("")).Message;
                var Detalhe = exception.StackTrace;
                var IP = Request.UserHostAddress;
                var UrlMetodo = (Request.Url.AbsoluteUri != null ? Request.Url.AbsoluteUri.ToString() : "NÃO LOCALIZADO");
                var UrlNavegador = (Request.UrlReferrer != null ? Request.UrlReferrer.ToString() : "NÃO LOCALIZADO");

                sbCorpoEmail.Append("<div style=\"font-family: tahoma, verdana; font-size: 10pt;\">");
                sbCorpoEmail.Append("-------------------------------------------------<BR>");
                sbCorpoEmail.Append("<b>Data:</b> " + Data.ToString("dd/MM/yyyy HH:mm:ss") + " <BR>");
                sbCorpoEmail.Append("<b>Url do Navegador:</b> " + UrlNavegador + "<BR>");
                sbCorpoEmail.Append("<b>Url do Método:</b> " + UrlMetodo + "<BR>");
                sbCorpoEmail.Append("<b>Descrição:</b> " + Descricao + "<BR>");
                sbCorpoEmail.Append("<b>Detalhe:</b> " + Detalhe + "<BR>");
                sbCorpoEmail.Append("<b>IP:</b> " + IP + "<BR>");
                sbCorpoEmail.Append("-------------------------------------------------");
                sbCorpoEmail.Append("</div>");

                try
                {
                    //Mail.Enviar(Config.systemName + " -  Reenvio de Senha", 
                    //            sbCorpoEmail.ToString(), 
                    //            Config.smtpFrom, 
                    //            (code == 500 ? "suporte@gsgroup.com.br;" : "") + Config.systemOwnerNotify);
                }
                catch { }
            }

            Server.ClearError();

            if (exception.GetType() == typeof(PermissionException))
            {
                Response.Redirect("/permissao");
                return;
            }

            Response.Redirect("~/");  
            
        }
    }
}
