﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Optimization;

namespace CPFL.COM.Template.UI
{
    public class BundleOrderer : IBundleOrderer
    {
        public virtual IEnumerable<BundleFile> OrderFiles(BundleContext context, IEnumerable<BundleFile> files)
        {
            return files;
        }
    }

    public class BundleConfig
    {
        public static void AddDefaultIgnorePatterns(IgnoreList ignoreList)
        {
            if (ignoreList == null)
            {
                throw new ArgumentNullException("ignoreList");
            }

            ignoreList.Ignore("*.intellisense.js");
            ignoreList.Ignore("*-vsdoc.js");
            ignoreList.Ignore("*.debug.js", OptimizationMode.WhenEnabled);
        }

        // For more information on bundling, visit https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.IgnoreList.Clear();
            AddDefaultIgnorePatterns(bundles.IgnoreList);

            //BundleTable.EnableOptimizations = false;

            bundles.Add(new ScriptBundle("~/bundle/js/jquery").Include(
                "~/Scripts/jquery-3.3.1.slim.min.js",
                "~/Scripts/jquery-3.2.1.min.js"));


            bundles.Add(new ScriptBundle("~/bundle/js/basic").Include(
                "~/Scripts/popper.min.js",
                "~/Scripts/bootstrap.js",
                "~/Scripts/slide-toggle.js"));

            //Javascript validações
            bundles.Add(new ScriptBundle("~/bundle/js/validation") { Orderer = new BundleOrderer() }.Include(
                        "~/scripts/jquery.validate.min.js",
                        "~/scripts/additional-methods.min.js",
                        "~/scripts/jquery.validate/messages_pt_BR.js",
                        "~/scripts/jquery.validate/jquery-validation-methods.js",
                        //"~/scripts/jquery.validate.unobtrusive.min.js",
                        "~/scripts/validacao.js"
                        ));

            bundles.Add(new StyleBundle("~/bundle/css").Include(
                "~/css/bootstrap.css",
                "~/css/all.css",
                "~/css/custom.css",
                "~/content/PagedList.css",
                "~/css/common.css"));

            //bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
            //            "~/Scripts/jquery-{version}.js"));

            //bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
            //            "~/Scripts/jquery.validate*"));

            //// Use the development version of Modernizr to develop with and learn from. Then, when you're
            //// ready for production, use the build tool at https://modernizr.com to pick only the tests you need.
            //bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
            //            "~/Scripts/modernizr-*"));

            //bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
            //          "~/Scripts/bootstrap.js",
            //          "~/Scripts/respond.js"));

            //bundles.Add(new StyleBundle("~/Content/css").Include(
            //          "~/Content/bootstrap.css",
            //          "~/Content/site.css"));
        }
    }
}
