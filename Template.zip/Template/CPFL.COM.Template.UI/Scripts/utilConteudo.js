﻿$(document).ready(function () {

    $(document).on('keypress', '.onlyNumbers', function (e) {
        //if the letter is not digit then display error and don't type anything
        if (e.which !== 8 && e.which !== 0 && (e.which < 48 || e.which > 57)) {
            return false;
        }
    });

    $(document).on('change', '[class^=load-]', function () {

        var regex = /load-(\w+)/;

        var c = regex.exec($(this).attr('class'))[1];

        var aux = /(.+)Cadastro/.exec(location.href);

        var url;

        if (aux) {
            url = aux[1] + 'Load' + c;
        }
        else {
            url = location.href + '/Load' + c;
        }

        $.ajax(
            {
                type: 'POST',
                url: url.toLowerCase(),
                data: { id: this.value },
                cache: false,
                success: function (result) {
                    if (result.success) {
                        var combo = $('.' + c);
                        combo.empty();

                        $.each(result.Data, function () {
                            if (this.value && this.text) {
                                combo.append($('<option>').val(this.value).text(this.text));
                            } else {
                                combo.append($('<option>').val(this.Value).text(this.Text));
                            }
                        });
                    }
                    else {
                        MostrarMessageBox(result.Data);
                    }
                }
            });
    });

    $(document).on('change', '[class*=update-]', function () {
        var regex = /update-(\w+)/;

        var regExec = regex.exec($(this).attr('class'));

        var url = /(.+)Cadastro/.exec(location.href)[1] + 'Update' + regExec[1];

        $.ajax(
            {
                type: 'POST',
                url: url,
                data: { value: this.value },
                cache: false,
                success: function (result) {

                    if (result.success === undefined) {
                        $('#' + regExec[0]).html(result);
                    }
                    else {
                        MostrarMessageBox(result.Data);
                    }
                }
            });
    });

    $(document).on('click', '[class*=add-]', function () {
        var regex = /add-(\w+)/;
        var regExec = regex.exec($(this).attr('class'));
        $('#' + regExec[1].trim()).html('');
        result = '';

        var url = /(.+)cadastro/.exec(location.href)[1] + 'add' + regExec[1];
        
        $.ajax(
            {
                type: 'POST',
                url: url,
                data: $('#formCadastro').serialize(),
                cache: false,
                success: function (result) {
                    if (result.success === undefined) {
                        $('#' + regExec[1].trim()).html(result);
                    }
                    else {
                        MostrarMessageBox(result.Data);
                    }
                }
            });
    });

    $(document).on('click', '.removeRow', function () {
        $(this).parent().parent().remove();
    });

    $('[class*=autocomplete-]').on('keyup', function () {

    });

    $('.validaNumero').on('blur', function () {
        var valor = $(this).attr('tamanho');
        if (valor) {
            if (parseInt(this.value) < parseInt($(this).attr('tamanho'))) {
                MostrarSimpleMessageBox('O valor informado é menor do que o valor recomandado (Valor recomendado: ' + $(this).attr('tamanho') + ')');
            }
        }
    });

    $('.cep').on('blur', function () {

        $.ajax(
            {
                type: 'POST',
                url: '/cep',
                data: { cep: this.value },
                cache: false,
                success: function (result) {

                    var remover;
                    if (result !== null && result !== undefined) {
                        if (result.endereco !== null && result.endereco !== undefined) {
                            $('#Endereco').val(result.endereco);
                            $('#Bairro').val(result.bairro);
                            $('#Endereco').attr('readonly', false);
                            $('#Bairro').attr('readonly', false);

                            remover = $('[for=Endereco]')[1];
                            if (remover) {
                                remover.remove();
                            }
                            remover = $('[for=Bairro]')[1];

                            if (remover) {
                                remover.remove();
                            }

                        } else {
                            $('#Endereco').val('');
                            $('#Bairro').val('');
                            $('#Endereco').attr('readonly', false);
                            $('#Bairro').attr('readonly', false);

                        }

                        if (result.cidade !== null && result.cidade !== undefined) {
                            $('#Cidade').val(result.cidade);
                            $('#Estado').val(result.uf);
                            $('#estadoshow').val(result.uf);
                            $('#Cidade').attr('readonly', 'readonly');
                            $('#estadoshow').attr('disabled', 'disabled');

                            remover = $('[for=Cidade]')[1];
                            if (remover) {
                                remover.remove();
                            }
                            remover = $('[for=estadoshow]')[0];

                            if (remover) {
                                remover.remove();
                            }

                        } else {
                            $('#Cidade').val('');
                            $('#Estado').val('');
                            $('#estadoshow').val('');
                            $('#Cidade').attr('readonly', false);
                            $('#estadoshow').attr('disabled', false);
                        }
                    } else {
                        $('#Endereco').val('');
                        $('#Bairro').val('');
                        $('#Cidade').val('');
                        $('#Estado').val('');
                        $('#estadoshow').val('');
                        $('#Cidade').attr('readonly', false);
                        $('#estadoshow').attr('disabled', false);

                    }
                    //debugger;
                    //if (result != null && result != undefined) {
                    //	if (result.endereco != null && result.endereco != undefined) {
                    //		$('#endereco').val(result.endereco);
                    //		$('#bairro').val(result.bairro);
                    //		$('#endereco').attr('readonly', false);
                    //		$('#bairro').attr('readonly', false);

                    //		remover = $('[for=endereco]')[1];
                    //		if (remover) {
                    //		    remover.remove();
                    //		}
                    //		remover = $('[for=bairro]')[1];

                    //		if (remover) {
                    //		    remover.remove();
                    //		}

                    //	} else {
                    //		$('#endereco').val('');
                    //		$('#bairro').val('');
                    //		$('#endereco').attr('readonly', false);
                    //		$('#bairro').attr('readonly', false);

                    //	}

                    //	if (result.cidade != null && result.cidade != undefined) {
                    //		$('#cidade').val(result.cidade);
                    //		$('#estado').val(result.uf);
                    //		$('#estadoshow').val(result.uf);
                    //		$('#cidade').attr('readonly', 'readonly');
                    //		$('#estadoshow').attr('disabled', 'disabled');						

                    //		remover = $('[for=cidade]')[1];
                    //		if (remover){
                    //		    remover.remove();
                    //		}
                    //		remover = $('[for=estadoshow]')[0];

                    //		if (remover) {
                    //		    remover.remove();
                    //		}

                    //	} else {
                    //		$('#cidade').val('');
                    //		$('#estado').val('');
                    //		$('#estadoshow').val('');
                    //		$('#cidade').attr('readonly', false);
                    //		$('#estadoshow').attr('disabled', false);
                    //	}
                    //} else {
                    //	$('#endereco').val('');
                    //	$('#bairro').val('');
                    //	$('#cidade').val('');
                    //	$('#estado').val('');
                    //	$('#estadoshow').val('');
                    //	$('#cidade').attr('readonly', false);
                    //	$('#estadoshow').attr('disabled', false);

                    //}				
                }
            });

    });

    $(document).on('click', '.exportaXls', function () {

        var frm = $('form[class!=search-form]')[0];

        var auxAction = frm.action;

        frm.action = this.href;

        frm.submit();

        frm.action = auxAction;

        return false;
    })

});

AjaxQueryGrid = function (url, page, div) {

    var controle = $('.' + div);

    if (controle.length > 0) {
        controle.remove();
    } else {
        $('.pagination-container').remove();
    }

    $.ajax({
        url: url + '?page=' + page,
        type: 'POST',
        data: $('form').serialize(),
        cache: false,
        success: function (result) {
            $('#' + div).empty();
            $('#' + div).html(result);
        }
    });

    $('#' + div + ' .pagination-container').remove();
    $('.' + div + ' .pagination-container').remove();

};

var setChart = function (chart, name, data, color, colorByPoint) {

    if (!colorByPoint) {
        colorByPoint = false;
    }
    //chart.xAxis[0].setCategories([data[0].name]);
    if (chart.series[0]) {
        chart.series[0].remove();
    }
    chart.addSeries({
        name: name,
        data: data,
        color: color,
        colorByPoint: colorByPoint
    });
};