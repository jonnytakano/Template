﻿var Cadastro = {
    SubmitMsg: ''
};

var Msg = {
    ConfirmantionMsg: ''
};

$(document).ready(function () {
    // Submit do form
    $('#formCadastro, #formCadastro2').on('submit', function () {

        if (this.target === '') {
            MostrarConfirmBox({
                _mensagem: Cadastro.SubmitMsg, _simFunc: jQuery.proxy(function () {
                    EnviaForm.apply(this);
                }, this),
            });

            return false;
        }
    });

    $('#formRelatorio').validate({
        submitHandler: function (form) {

            $.post(window.location.href + '/validacoes', $('#formRelatorio').serialize(), function (result) {

                if (result.Data) {
                    MostrarMessageBox(result.Data);
                } else {
                    form.submit();
                }

            });
        }
    });

    $('#formAnalitico').validate({
        submitHandler: function (form) {

            //Ao clicar nesse botão, limpar todos os HIDDENs da tela				

            //OBS: VER AnaliticoProdutosConsumidos/Index
            if (!$('#LimpaHidden')) {
                var itens = $('input[type=hidden]');

                for (var i = 0; i < itens.length; i++) {
                    $(itens[i]).val('');
                }
            }

            $.post(window.location.href + '/validacoes', $('#formAnalitico').serialize(), function (result) {

                if (result.Data) {
                    MostrarMessageBox(result.Data);
                } else {
                    $.ajax({
                        //url: '/CategoriaConteudo/Filtro', //Ação a ser executada no controller
                        url: $('#formAnalitico').attr('action'),
                        type: 'POST', //Tipo do request
                        data: $('#formAnalitico').serialize(), //Passa os dados do formulário
                        cache: false,
                        success: function (result) {
                            //Atualiza o conteudo de alguma div para o partial
                            $('#divAtualizacao').html(result);
                        }
                    });

                }

            });
        }
    });

    $('#formRelatorio_OLD').on('submit', function () {

        $('#loading').modal('show');

        $.ajax(
            {
                type: 'POST',
                url: this.action,
                data: $(this).serialize(),
                cache: false,
                success: function (result) {

                    $('#loading').modal('hide');

                    if (!result.Data) {
                        //Atualiza o conteudo de alguma div para o partial
                        $('#divRelatorio').html(result);

                        $(window).resize();
                    }
                    else {
                        MostrarMessageBox(result.Data);
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    //var r = XMLHttpRequest.responseText;

                    //var erroRelatorio = r.substring(r.indexOf('[AlertException:')).substr(0, r.substring(r.indexOf('[AlertException:')).indexOf(']')).replace('[AlertException:', '').substring(1);

                    //if (erroRelatorio) {
                    //	MostrarSimpleMessageBox(erroRelatorio);
                    //} else {
                    MostrarSimpleMessageBox(errorThrown);
                    //}
                }
            })

        if (this.target === '') {
            MostrarConfirmBox({ _mensagem: Cadastro.SubmitMsg, _simFunc: jQuery.proxy(function () { EnviaForm.apply(this) }, this), })

            return false;
        }

        return false;

    });

    $(document).on('click', '[class*=confirmation]', function () {

        MostrarConfirmBox({ _mensagem: Msg.ConfirmantionMsg, _simFunc: jQuery.proxy(function () { }, this), });

        return false;

    });

    var EnviaForm = function (url) {

        // Se o formulário for do tipo que faz upload
        if (this.enctype === 'multipart/form-data') {
            // Faz com que o post do form seja feito dentro do iframe
            this.target = 'formUpload';

            $('body').append($('<iframe>').attr({ 'id': 'formUpload', 'name': 'formUpload', 'style': 'display: none' }));

            $('#loading').modal('show');
            this.action = this.action.toLowerCase();
            this.submit();

            // Função executada após carregar o iframe
            $('#formUpload').on('load', function () {
                $('#loading').modal('hide');

                var result = $.parseJSON($(this).contents().find("body").html().replace('<pre>', '').replace('</pre>', ''));

                MostrarMessageBox(result.Data);

                $('#formUpload').remove();
            });

            this.target = '';
        }
        else {
            var urlPost = url || this.action;

            $.ajax(
                {
                    type: 'POST',
                    url: urlPost.toLowerCase(),
                    data: $(this).serialize(),
                    cache: false,
                    success: function (result) {
                        MostrarMessageBox(result.Data);
                    }
                });
        }
    };

    $(document).on('click', '[class*=post-]', function () {
        if ($(this).parents('.validationGroup').validGroup()) {
            var regex = /post-(\w+)/;

            var regExec = regex.exec($(this).attr('class'));

            var regUrl = /(.+)cadastro/.exec(location.href);

            var url = '';

            if (regUrl !== null) {
                url = /(.+)cadastro/.exec(location.href)[1] + regExec[1];
            }
            else {
                url = location.href + '/' + regExec[1];
            }

            $.ajax(
                {
                    type: 'POST',
                    url: url.toLowerCase(),
                    data: $('#formCadastro').serialize(),
                    cache: false,
                    success: function (result) {
                        MostrarMessageBox(result.Data);
                    }
                });
        }

        return false;
    });

    $(document).on('click', '[class*=postConfirm-]', function () {
        if ($(this).parents('.validationGroup').validGroup()) {

            var obj = $(this);

            MostrarConfirmBox({
                _mensagem: obj.attr('msg'), _simFunc: jQuery.proxy(function () {

                    var regex = /postConfirm-(\w+)/;

                    var regExec = regex.exec(obj.attr('class'));

                    var regUrl = /(.+)cadastro/.exec(location.href);

                    var url = '';

                    if (regUrl !== null) {
                        url = /(.+)cadastro/.exec(location.href)[1] + regExec[1];
                    }
                    else {
                        url = location.href + '/' + regExec[1];
                    }

                    $.ajax(
                        {
                            type: 'POST',
                            url: url.toLowerCase(),
                            data: $('#formCadastro').serialize(),
                            cache: false,
                            success: function (result) {
                                MostrarMessageBox(result.Data);
                            }
                        });

                }, this),
            });




        }

        return false;
    });

    $(document).on('click', '[class*=insert-]', function () {

        if ($(this).parents('.validationGroup').validGroup()) {

            /* regexFull - responsável por fazer o post em URL/{Controller}/{Action} */
            var regex = /insert-(\w+)/;
            var regexFull = /insert-(\w+)-(\w+)/;

            var regExec = regex.exec($(this).attr('class'));
            var regExecFull = regexFull.exec($(this).attr('class'));

            var regUrl = /(.+)cadastro/.exec(location.href);

            var url = ''

            if (regExecFull !== null && regExecFull[2] !== null) {
                //url = location.origin + '/' + regExecFull[1] + '/' + regExecFull[2]
                url = location.protocol + '//' + location.host + '/' + regExecFull[1] + '/' + regExecFull[2];
                EnviarInsertDelete(url, regExecFull[2].replace('-', ''));
            } else {
                if (regUrl !== null) {
                    url = /(.+)cadastro/.exec(location.href)[1] + 'Insert' + regExec[1];
                    EnviarInsertDelete(url, regExec[0].replace('-', ''));
                }
                else {
                    url = location.href + '/Insert' + regExec[1];
                    EnviarInsertDelete(url, regExec[0].replace('-', ''));
                }
            }

            var regexLimpa = /limpa-(\w+)/;

            var regexClean = /clean-(\w+)/;
            var regexCleanFull = /clean-(\w+)-(\w+)/;

            var regLimpa = regexLimpa.exec($(this).attr('class'));
            var regClean = regexClean.exec($(this).attr('class'));
            var regCleanFull = regexCleanFull.exec($(this).attr('class'));

            url = url.toLowerCase();

            if (regLimpa !== null) {
                LimpaForm(regLimpa[1]);
            } else {
                if (regCleanFull !== null) {
                    url = location.protocol + '//' + location.host + '/' + regCleanFull[1] + '/' + regCleanFull[2];
                    //url = location.origin + '/' + regCleanFull[1] + '/' + regCleanFull[2]
                    EnviarInsertDelete(url, regCleanFull[2]);
                } else {
                    if (regClean) {
                        url = location.protocol + '//' + location.host + '/Update' + regClean[1];
                        EnviarInsertDelete(url, 'insert' + regClean[1]);
                    }
                }
            }

        }

        return false;
    });

    $(document).on('click', '[class*=delete-]', function () {
        var regex = /delete-(\w+)/;

        var regExec = regex.exec($(this).attr('class'));

        var jsonId = 'json' + regExec[1];

        EnviarInsertDelete(this.href, 'insert' + regExec[1]);

        return false;
    });

    var EnviarInsertDelete = function (url, controle) {

        var form = $('#formCadastro').serialize();

        if (form.length <= 0) {
            form = $('#formRelatorio').serialize();
        }

        if (form.length <= 0) {
            form = $('#formAnalitico').serialize();
        }

        $.ajax(
            {
                type: 'POST',
                url: url.toLowerCase(),
                data: form,
                cache: false,
                success: function (result) {
                    if (result.success === undefined) {
                        $('.' + controle).empty();
                        $('.' + controle).html(result);
                    }
                    else {
                        MostrarMessageBox(result.Data);
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    MostrarSimpleMessageBox(errorThrown);
                }
            });
    };

    var LimpaForm = function (classe) {

        var checkHidden = "";

        var inputs = $('.' + classe + ' input');
        for (var i = 0; i < inputs.length; i++) {

            if ($(inputs[i]).attr('type') !== 'checkbox') {

                if ($(inputs[i]).attr('id') !== checkHidden) {
                    $(inputs[i]).val('');
                }
            } else {
                checkHidden = $(inputs[i]).attr('id');
            }
        }

        var combos = $('.' + classe + ' select');
        for (var i = 0; i < combos.length; i++) {
            $(combos[i]).val('');
        }

        var checks = $('.' + classe + ' input[type="checkbox"]');
        for (var i = 0; i < checks.length; i++) {
            $(checks[i]).attr('checked', false);

        }
    };

    var EnviaForm = function (url) {

        // Se o formulário for do tipo que faz upload        
        if (this.enctype === 'multipart/form-data') {
            var action = this.action;
            this.action = url || this.action;

            this.action = this.action.toLowerCase();
            // Faz com que o post do form seja feito dentro do iframe
            this.target = 'formUpload';

            $('body').append($('<iframe>').attr({ 'id': 'formUpload', 'name': 'formUpload', 'style': 'display: none' }));

            $('#loading').modal('show');
            this.submit();

            // Função executada após carregar o iframe
            $('#formUpload').on('load', function () {
                $('#loading').modal('hide');
                $(this).contents().find("pre").removeAttr('style');//remover atributo style da tag <pre> *chrome
                var result = $.parseJSON($(this).contents().find("body").html().replace('<pre>', '').replace('</pre>', ''));

                MostrarMessageBox(result.Data);

                $('#formUpload').remove();
            });

            this.target = '';
            this.action = action;
        }
        else {
            var urlPost = url || this.action;

            $.ajax(
                {
                    type: 'POST',
                    url: urlPost.toLowerCase(),
                    data: $(this).serialize(),
                    cache: false,
                    success: function (result) {
                        if (result.html !== undefined && result.html.length !== 0) {
                            //Atualiza o conteudo de alguma div para o partial
                            $('#divAtualizacaoGaleriaFoto').html(result.html);
                            MostrarMessageBox(result.mensagem.Data);
                        }
                        else {
                            var resultConvertido = result;
                            if (!result.Data) {
                                if (result.indexOf('_tipoMensagem') > 0) {
                                    resultConvertido = JSON.parse(result);
                                }
                            }

                            if (!resultConvertido.Data) {
                                $("#divResultado").empty();
                                $("#divResultado").html(result);
                            }
                            else {
                                MostrarMessageBox(resultConvertido.Data);
                            }
                        }
                    }
                });
        }

        $('#modalAlt').modal('hide');
    };
});