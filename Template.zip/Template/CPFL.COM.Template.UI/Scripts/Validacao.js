﻿var Validacao = {
	rules: {},
	messages: {}
}

$(document).ready(function () {
	var rules = {
		'.required': { required: true },
		Resposta: {
			required: function () {
				CKEDITOR.instances.Resposta.updateElement();
			},
			minlength: 8
		}
	}

	$.extend($.fn, {
		validGroup: function () {
			if (!$(this).is('.validationGroup')) {
				return true
			}

			var isValid = true

			this.find(':input').each(function (i, item) {
				if (!$(item).valid()) {
					isValid = false
				}
			})

			return isValid
		}
	})

	$('.validationGroup').keydown(function (event) {
		if (event.keyCode == 13) {
			$('.validationGroup .causesValidation').click()
			event.preventDefault()
		}
	})


	$('.Validacao').validate(
  {

  	ignore: 'input:hidden:not(input:hidden.ckeditor), .validationGroup :input',

  	onsubmit: false,

  	rules: $.extend(Validacao.rules, rules),
  	messages: Validacao.messages,

  	errorElement: 'span',
  	errorClass: 'help-block',

  	highlight: function (element) {

  		if (element.type == 'file') {
  			$(element).closest('.form-group').removeClass('has-success').addClass('has-error')
  			window.scrollTo($(element).closest('.form-group').position().left, $(element).closest('.form-group').position().top);
  		}
  		else if ($(element).closest('.validationGroup').length == 1) {
  			$(element).parent().removeClass('has-success').addClass('has-error')
  			window.scrollTo($(element).parent().position().left, $(element).parent().position().top);
  		}
  		else {
  			if ($($(element).parent().parent())[0].id == 'formCadastro') {
  				$(element).parent().removeClass('has-success').addClass('has-error')

  				//Validação de ckeditor
  				if ($(element).hasClass("ckeditor")) {
  					$(element).next().addClass('form-control');
  				}

  				window.scrollTo($(element).parent().position().left, $(element).parent().position().top);
  			} else {
  				window.scrollTo($(element).parent().parent().position().left, $(element).parent().parent().position().top);
  				$(element).parent().parent().removeClass('has-success').addClass('has-error')
  			}
  		}
  	},

  	unhighlight: function (element) {
  		if (element.type == 'file') {
  			$(element).closest('.form-group').removeClass('has-error')
  		}
  		else if ($(element).closest('.validationGroup').length == 1) {
  			$(element).parent().removeClass('has-error');
  		}
  		else {
  			if ($($(element).parent().parent())[0].id == 'formCadastro') {
  				$(element).parent().removeClass('has-error');
  			} else {
  				$(element).parent().parent().removeClass('has-error');
  			}

  		}
  	},

  	errorPlacement: function (error, element) {
  		if (element[0].type == "file") {
  			error.appendTo($(element).closest('.controls'))
  		}
  		else if (element.hasClass("ckeditor")) {
  			error.insertAfter(element.next());
  		}
  		else {
  			error.insertAfter(element);
  		}
  	}
  })

	var fnClick = function (event) {
		if (!$($(this).closest('form')[0]).valid()) {
			event.preventDefault()
		}
	}

	$(".Validacao button[type=submit]").click(fnClick)
	$(".Validacao input[type=submit]").click(fnClick)
})