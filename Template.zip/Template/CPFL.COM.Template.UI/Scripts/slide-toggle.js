$(document).ready(function() {
	/*MENU PRINCIPAL*/
	$(".slide-toggle").click(function(){
        $(".box").animate({width: "toggle"});
        $(".slide-toggle").toggleClass("btn-menu-ativo");
	});

	$(".menu-item").click(function(){
        $(this).toggleClass("menu-item-ativo");
	});

	/*LEGENDA*/
	$(".slide-toggle-legenda").click(function(){
        $(".box-legenda").animate({width: "toggle"});
	});
});