﻿var useOrder = true;
var columnOrder = 1;
var ascDesc = 'asc';

$(document).ready(function () {
    // Cria o DataTable
    //AtualizaDataTable('tblListagem', useOrder, columnOrder, ascDesc)

    // Submit do form de pesquisa
    $(document).on('submit', '#formPesquisa', function () {
        if (!this.action.match("Exportar$")) {
            EnviarForm(this);
            return false;
        }
    });

    var EnviarForm = function (frm, url) {

        var urlPost = url || frm.action;

        $.ajax(
            {
                type: 'POST',
                url: urlPost.toLowerCase(),
                data: $(frm).serialize(),
                cache: false,
                success: function (result) {

                    if (!result.Data) {
                        //Atualiza o conteudo de alguma div para o partial
                        $('#divAtualizacao').html(result);
                        //Atualiza DataTable
                        //AtualizaDataTable('tblListagem', useOrder, columnOrder, ascDesc);
                    }
                    else {
                        MostrarMessageBox(result.Data);
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    MostrarSimpleMessageBox(errorThrown);
                }
            });
    };

    // Clique do botão atualizar
    $(document).on("click", "#lnkAtualizar", function () {
        EnviarForm($('#formPesquisa')[0], this.href);

        return false;
    });

    // Clique dos botões de paginação
    $(document).on("click", ".pagination a", function () {
        EnviarForm($('#formPesquisa')[0], this.href);

        return false;
    });

    // Clique do botão excluir
    $(document).on('click', '#btnExcluir', function () {
        MostrarConfirmBox({ _mensagem: $(this).attr('msg'), _simFunc: jQuery.proxy(function () { Excluir.apply(this) }, this) });

        return false;
    });

    var Excluir = function () {
        EnviarForm($('#formPesquisa')[0], this.href);
    };

    // Clique do botão AlterarStatus
    $(document).on('click', '#btnAlterarStatus', function () {
        MostrarConfirmBox({ _mensagem: $(this).attr('msg'), _simFunc: jQuery.proxy(function () { AlterarStatus.apply(this) }, this) });

        return false;
    });

    var AlterarStatus = function () {
        EnviarForm($('#formPesquisa')[0], this.href);
    };

    // Clique do botão exportar
    $(document).on('click', '#btnExportar', function () {
        var frm = $('#formPesquisa')[0];

        var auxAction = frm.action;

        frm.action = this.href;

        frm.submit();

        frm.action = auxAction;

        return false;
    });

    // Clique dos botões de ação
    $(document).on("click", ".action", function () {
        EnviarForm($('#formPesquisa')[0], this.href);

        return false;
    });

    //========FUNÇÃO DISPARADA QUANDO CLICAR NO BOTÃO PESQUISAR==============================================================================
    $(document).on("click", "#btnPesquisar", function () {
        if (this.attributes['href']) {
            $.ajax({
                //url: '/CategoriaConteudo/Filtro', //Ação a ser executada no controller
                url: this.attributes['href'].value,
                type: 'POST', //Tipo do request
                data: $('#formListagem').serialize(), //Passa os dados do formulário
                cache: false,
                success: function (result) {
                    //Atualiza o conteudo de alguma div para o partial
                    $('#divAtualizacao').html(result);
                    $('#loading').modal('hide');
                    //Atualiza DataTable
                    //AtualizaDataTable('tblListagem');
                }
            });
            return false;
        }

    });

    // Clique do botão excluir
    $(document).on("click", ".btnRemover", function () {

        $.ajax({
            url: this.attributes['href'].value,
            data: {
                id: this.attributes['id'].value
            },
            type: 'POST',
            cache: false,
            success: function (result) {
                MostrarMessageBox(result.Data);
            }
        });

        return false;

    });
});