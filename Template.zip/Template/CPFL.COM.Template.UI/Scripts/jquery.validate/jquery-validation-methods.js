﻿jQuery.validator.addMethod("numberBr", function (value, element) {
    return this.optional(element) || /^-?(?:\d+|\d{1,3}(?:\.\d{3})+)?(?:,\d+)?$/.test(value);
}, jQuery.validator.messages.number);

jQuery.validator.addMethod("notEqualTo", function (value, element, param) {
    var target = $(param);

    if (this.settings.onfocusout) {
        target.unbind(".validate-notEqualTo").bind("blur.validate-notEqualTo", function () {
            $(element).valid();
        });
    }

    return value !== target.val();
}, "Os campos devem ter valores diferentes");

jQuery.validator.addMethod("minBr", function (value, element, param) {
    return this.optional(element) || value.replace(/\./g, ';').replace(/,/g, '.').replace(/;/g, ',') >= param;
}, jQuery.validator.messages.min);

jQuery.validator.addMethod("maxBr", function (value, element, param) {

    return this.optional(element) || value.replace(/\./g, ';').replace(/,/g, '.').replace(/;/g, ',') <= param;
}, jQuery.validator.messages.max);

jQuery.validator.addMethod("maxBrResgate", function (value, element, param) {

    return this.optional(element) || value.replace(/\./g, ';').replace(/,/g, '.').replace(/;/g, ',') <= param;
}, "A quantidade informada atinge o limite do resgate desse prêmio para esse CPF.");

jQuery.validator.addMethod("dateBr", function (value, element) {

    if (value == '__/__/____' || value == '__-__-____' || value == '__.__.____' || value == '')
        return true;

    //valida formatos dd/mm/yyyy, dd-mm-yyyy ou dd.mm.yyyy
    var rxDate = /^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/|-|\.)(?:0?[1,3-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$/;

    if (value.match(rxDate)) {
        return true;
    }
    else {
        return false;
    }

}, jQuery.validator.messages.date);


var auxMask = "";

jQuery.validator.addMethod("DecimalValida", function (value, element, param) {

    auxMask = "";

    var lstVal = param.split('.');

    var c1 = parseInt(lstVal[0]) - parseInt(lstVal[1]);
    var c2 = parseInt(lstVal[1]);

    for (var i = 0; i < c1; i++) {
        auxMask = auxMask + "x";
    }

    auxMask = auxMask + ",";

    for (var i = 0; i < c2; i++) {
        auxMask = auxMask + "x";
    }

    var rxDecimal = '(^(100(?:\\,0{1,' + c1 + '})?))|(?!^0*$)(?!^0*\\.0*$)^\\d{1,' + c1 + '}(\\,\\d{1,' + c2 + '})?$';

    var reg = new RegExp(rxDecimal);

    if (value.match(reg)) {
        return true;
    }
    else {
        return false;
    }

}, function () { return jQuery.validator.messages.number + " Ex:(" + auxMask + ")"; }
);

jQuery.validator.addMethod("hora", function (value, element) {
    if (value == '__:__' || value == '')
        return true;

    var rxHora = /^([0-1][0-9]|[2][0-3]):[0-5][0-9]$/;

    if (value.match(rxHora)) {
        return true;
    }
    else {
        return false;
    }

}, "Por favor, preencha a hora corretamente.");

jQuery.validator.addMethod("dataHora", function (value, element) {
    if (value == '__/__/____ __:__' || value == '__-__-____ __:__' || value == '__.__.____ __:__' || value == '')
        return true;

    var rxData = /^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/|-|\.)(?:0?[1,3-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$/;
    var rxHora = /^([0-1][0-9]|[2][0-3]):[0-5][0-9]$/;

    var dataHora = value.split(" ");

    if (dataHora[0].match(rxData) && dataHora[1].match(rxHora)) {
        return true;
    }
    else {
        return false;
    }

}, "Por favor, preencha corretamente a data e hora");


$.validator.addMethod("verificaCPF", function (value, element) {
    value = value.replace('.', '');
    value = value.replace('.', '');
    cpf = value.replace('-', '');
    while (cpf.length < 11) cpf = "0" + cpf;


    if (cpf == "01234567890")
        return false;

    var expReg = /^0+$|^1+$|^2+$|^3+$|^4+$|^5+$|^6+$|^7+$|^8+$|^9+$/;
    var a = [];
    var b = new Number;
    var c = 11;
    for (i = 0; i < 11; i++) {
        a[i] = cpf.charAt(i);
        if (i < 9) b += (a[i] * --c);
    }
    if ((x = b % 11) < 2) { a[9] = 0 } else { a[9] = 11 - x }
    b = 0;
    c = 11;
    for (y = 0; y < 10; y++) b += (a[y] * c--);
    if ((x = b % 11) < 2) { a[10] = 0; } else { a[10] = 11 - x; }
    if ((cpf.charAt(9) != a[9]) || (cpf.charAt(10) != a[10]) || cpf.match(expReg)) return false;
    return true;
}, "Informe um CPF válido."); // Mensagem padrão

$.validator.addMethod("verificaCNPJ", function (value, element) {

    cnpj = value.replace(/[^\d]+/g, '');

    if (cnpj == '') return false;

    if (cnpj.length != 14)
        return false;

    // LINHA 10 - Elimina CNPJs invalidos conhecidos
    if (cnpj == "00000000000000" ||
        cnpj == "11111111111111" ||
        cnpj == "22222222222222" ||
        cnpj == "33333333333333" ||
        cnpj == "44444444444444" ||
        cnpj == "55555555555555" ||
        cnpj == "66666666666666" ||
        cnpj == "77777777777777" ||
        cnpj == "88888888888888" ||
        cnpj == "99999999999999")
        return false; // LINHA 21

    // Valida DVs LINHA 23 -
    tamanho = cnpj.length - 2
    numeros = cnpj.substring(0, tamanho);
    digitos = cnpj.substring(tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2)
            pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(0))
        return false;

    tamanho = tamanho + 1;
    numeros = cnpj.substring(0, tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2)
            pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(1))
        return false;

    return true;
}, "Informe um CNPJ válido."); // Mensagem padrão

$.validator.addMethod("verificaEmail", function (value, element) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(value);
}, "E-mail inválido"); // Mensagem padrão

//jQuery.validator.addMethod("dataBanco", function (value, element) {
//	var data = new Date(1900, 12, 01);
//	if (!/Invalid|NaN/.test(new Date(value))) {
//		return new Date(value) > data;
//	}
//	return isNaN(value) || (parseFloat(value) > data);
//}, "Data inválida");

jQuery.validator.addMethod("campoTelefone", function (value, element) {
    return value.length >= 14;
}, "Telefone inválido");

jQuery.validator.addMethod("maxBrDecimal", function (value, element, param) {

    return this.optional(element) || parseFloat(value.replace(/\./g, ';').replace(/,/g, '.').replace(/;/g, ',')) <= param;
}, jQuery.validator.messages.max);



