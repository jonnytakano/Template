﻿using CPFL.COM.Template.Common;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.ViewModel;
using CPFL.COM.Template.Service.Interfaces;
using CPFL.COM.Template.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace CPFL.COM.Template.UI.Controllers
{
    [AllowAnonymous]
    public class LoginController : MasterController
    {
        #region [  Initializers  ]

        private IUsuarioService _usuarioService;

        public LoginController(IUsuarioService usuarioService)
        {
            _usuarioService = usuarioService;
        }

        #endregion


        // GET: Login
        public ActionResult Index()
        {
            //var ab = _usuarioService.Get(1);
            //ab.Nome += "1";
            //_usuarioService.Update(ab);


            Usuario obj = _usuarioService.InformacoesUsuario();
            var usuario = _usuarioService.GetByMatricula(obj.Matricula);

            if (usuario != null)
            {
                var url = Sessao.Login(usuario);
                usuario.UltimoAcesso = DateTime.Now;
                _usuarioService.Update(usuario);

                Response.Redirect(url);
            }
            else
            {
                Response.Redirect(Url.Action("SemCadastro"));
            }

            return View();
        }


        public ActionResult SemCadastro ()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Autenticar(LoginViewModel model)
        {
            try
            {
                var result = new JSONResult();

                #region [  LOGIN  ]

                //Perfil objPerfil = null;

                //model.Login = Helper.RemoveMask(model.Login);

                //#region [ VALIDAÇÃO ]

                //var camposInvalidos = new List<string>();

                //if (model.Login.IsNullOrWhiteSpace())
                //{
                //    camposInvalidos.Add("CPF");
                //}

                //if (model.Senha.IsNullOrWhiteSpace())
                //{
                //    camposInvalidos.Add("Senha");
                //}

                //if (camposInvalidos.Count > 0)
                //{
                //    throw new AlertException(Messages.MN0005(camposInvalidos));
                //}

                //#endregion

                //model.Senha = Encryption.Encrypt(model.Senha);

                //var usuario = _usuarioAppService.Autenticar(model.Login, model.Senha);

                //if (usuario == null || usuario.IdStatusAcesso != (long)eStatusAcesso.Permitido)
                //{
                //    if (usuario != null && usuario.IdStatusAcesso == (long)eStatusAcesso.Bloqueado)
                //    {
                //        throw new ErrorException(Messages.MN0023);
                //    }
                //    else
                //    {
                //        throw new ErrorException(Messages.MN0006);
                //    }
                //}


                //if (usuario.UsuarioPerfil.Count > 1 && model.Perfil == null)
                //{
                //    return View("_EscolhePerfil", usuario.UsuarioPerfil.ToList());
                //}
                //else
                //{
                //    if (!model.Perfil.IsNullOrWhiteSpace())
                //    {
                //        objPerfil = (from p in usuario.UsuarioPerfil
                //                     where p.Id == model.Perfil.Value
                //                     select p.Perfil).FirstOrDefault();
                //    }
                //    else
                //    {
                //        objPerfil = usuario.UsuarioPerfil.Select(q => q.Perfil).FirstOrDefault();
                //    }

                //    result.Data = new
                //    {
                //        url = Sessao.Login(usuario, objPerfil)
                //    };
                //}

                #endregion

                var cookie = String.Format("{0}|{1}", "0", "0");

                FormsAuthentication.SetAuthCookie(cookie, false);
                result.Data = new
                {
                    url = "/"
                };

                return JSONConvert.Get(result);
            }
            catch (Exception ex)
            {
                return MessageBox.ShowMessage(ex);
            }

            //if (ModelState.IsValid)
            //{
            //    ModelState.Clear();

            //    ILoginBLO _service = ServiceLocator.Current.GetInstance<ILoginBLO>();
            //    var login = _service.ValidarLogin(loginViewModel.Usuario, loginViewModel.Senha);

            //    if (login.Valido)
            //    {
            //        Session["Usuario"] = login.UsuarioSessao;
            //        FormsAuthentication.SetAuthCookie(login.UsuarioSessao.Nome, false);
            //        return RedirectToAction("Index", "Dashboard");
            //    }
            //    else
            //    {
            //        ViewBag.ErroUsuario = "Seu acesso no sistema não possui centro de operações cadastrado. Contate seu superior para esclarecimentos. ";
            //    }
            //    return View("Index", loginViewModel);
            //}
            //else
            //{
            //    return View("Index", loginViewModel);
            //}

            //return Json("");
        }

        public ActionResult Logout()
        {
            Sessao.Logout();

            return RedirectToAction("index", "login");
        }
    }
}