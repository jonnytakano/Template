﻿using CPFL.COM.Template.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Reflection;
using System.Collections;
using System.Text;

namespace CPFL.COM.Template.UI.Controllers
{
    public class MasterController : Controller
    {
        private List<string> ActionsParaPermissoes = new List<string>() { "cadastro", "filtro", "index", "excluir", "exportar" };

        protected virtual string TituloPagina { get { return ""; } }

        protected override void OnActionExecuting(ActionExecutingContext ctx)
        {
            ViewBag.Title = TituloPagina;
            string nomeController = ctx.ActionDescriptor.ControllerDescriptor.ControllerName.ToLower();

            if (Sessao.Aplicacao != null)
            {
                var Aplicacao = Sessao.Aplicacao.Where(q => q.Aplicacao.Controller.ToUpper() == nomeController.ToUpper()).FirstOrDefault();

                if (Aplicacao != null)
                {
                    var action = ctx.ActionDescriptor.ActionName.ToLower();

                    if (action.StartsWith("delete"))
                    {
                        action = "Excluir";
                    }

                    if (ActionsParaPermissoes.Contains(action))
                    {

                        if (action.Equals("cadastro") || action.Equals("salvar"))
                        {
                            if (ctx.RouteData.Values["id"] != null)
                            {
                                action = "Alterar";
                            }
                            else
                            {
                                action = "Inserir";
                            }
                        }

                        var possuiPermissao = Aplicacao.GetType().GetProperty(PreparaPropriedadePermissao(action)).GetValue(Aplicacao).ToNBoolean();

                        if (possuiPermissao.HasValue)
                        {
                            if (!possuiPermissao.Value)
                            {
                                //Se for Ajax, retorna a mensagem de "erro" 
                                if (HttpContext.Request.IsAjaxRequest())
                                {
                                    ctx.Result = new HttpNotFoundResult(Messages.MN0009);
                                }
                                else
                                {
                                    throw new PermissionException();
                                }

                            }
                        }
                    }
                }
            }

            ViewBag.AssemblyVersion = Assembly.GetExecutingAssembly().GetName().Version.ToString();
        }

        private string PreparaPropriedadePermissao(string action)
        {
            switch (action.ToLower())
            {
                case "index": return "Visualizar";
                case "cadastro": return "Inserir";
                case "salvar": return "Alterar";
                case "filtro": return "Pesquisar";
                case "excluir": return "Excluir";
                case "exportar": return "Exportar";
                default: return action;
            }
        }

        protected string Errors(ModelStateDictionary modelState)
        {
            var sb = new StringBuilder();

            if (!modelState.IsValid)
            {
                var mensagens = modelState.ToDictionary(kvp => kvp.Key,
                                         kvp => kvp.Value.Errors
                                                         .Select(e => e.ErrorMessage).ToArray())
                                                         .Where(m => m.Value.Count() > 0);
                
                foreach (var item in mensagens)
                {
                    foreach (var erroOnItem in item.Value)
                    {
                        sb.Append(erroOnItem + "<br>");
                    }
                }

                ModelState.AddModelError("error", "true");

            }

            return sb.ToString();
        }
        //protected Dictionary<KeyValuePair<string, ModelState>, string, string[]>  Errors(ModelStateDictionary modelState)
        //{
        //    if (!modelState.IsValid)
        //    {
        //        ModelState.AddModelError("error", "true");
        //        var aaaa = modelState.ToDictionary(kvp => kvp.Key,
        //             kvp => kvp.Value.Errors
        //                             .Select(e => e.ErrorMessage).ToArray())
        //                             .Where(m => m.Value.Count() > 0);

        //        return aaaa;
        //    }
        //    return null;
        //}
    }
}