﻿using CPFL.COM.Template.Common;
using CPFL.COM.Template.Domain.Entities;
using CPFL.COM.Template.Domain.ViewModel;
using CPFL.COM.Template.Service.Interfaces;
using PagedList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;
using TipoDB = CPFL.COM.Template.Domain.Entities.Perfil;
using ViewDB = CPFL.COM.Template.Domain.ViewModel.PerfilViewModel;

namespace CPFL.COM.Template.UI.Controllers.Security
{
    public class PerfilController : MasterController
    {
        #region [  Initializers  ]

        private IPerfilService _perfilService;
        private IPerfilAplicacaoService _perfilAplicacaoService;
        private IAplicacaoService _aplicacaoService;

        public PerfilController(IPerfilService perfilService, IPerfilAplicacaoService perfilAplicacaoService, IAplicacaoService aplicacaoService)
        {
            _perfilService = perfilService;
            _perfilAplicacaoService = perfilAplicacaoService;
            _aplicacaoService = aplicacaoService;
        }

        protected override string TituloPagina { get { return "Perfil"; } }

        #region [  Internal Methods  ]

        private TipoDB PreparaGrid(TipoDB obj, ViewDB model)
        {
            var aux = new List<PerfilAplicacao>();
            foreach (var item in model.PerfilAplicacao)
            {
                var atual = obj.PerfilAplicacao.Where(q => q.Id == item.Id).FirstOrDefault();

                //Se for NULL, adiciona
                if (atual.IsNullOrEmpty())
                {
                    aux.Add(new PerfilAplicacao()
                    {
                        Alterar = item.Alterar,
                        Excluir = item.Excluir,
                        Exportar = item.Exportar,
                        Id = item.Id,
                        IdAplicacao = item.IdAplicacao,
                        IdPerfil = item.IdPerfil,
                        Inserir = item.Inserir,
                        Pesquisar = item.Pesquisar,
                        Visualizar = item.Visualizar,
                        Ativo = true
                    });
                }
                else //Se já existir, altera
                {
                    atual.Visualizar = item.Visualizar;
                    atual.Inserir = item.Inserir;
                    atual.Alterar = item.Alterar;
                    atual.Pesquisar = item.Pesquisar;
                    atual.Excluir = item.Excluir;
                    atual.Exportar = item.Exportar;
                }
            }

            aux.ForEach(q => obj.PerfilAplicacao.Add(q));

            return obj;
        }

        #endregion

        #endregion

        public ActionResult Index()
        {
            ViewBag.TituloPagina = TituloPagina;
            return View();
        }

        [HttpPost]
        public ActionResult Filtro(int page = 1, ViewDB model = null)
        {
            try
            {
                var dados = _perfilService.Filter(model, page);
                return View("_Filtro", dados.ToPagedList(page, Const.RecordCountPerPage));
            }
            catch (Exception ex)
            {
                return MessageBox.ShowMessage(ex);
            }
        }

        public ActionResult Cadastro(long id = 0)
        {
            var model = new ViewDB();
            ViewBag.TituloPagina = TituloPagina;
            ViewBag.SubmitMsg = Messages.MA0002;

            if (id > 0)
            {
                ViewBag.SubmitMsg = Messages.MA0003;
                model = (ViewDB)_perfilService.Get(id);

                List<Aplicacao> NovasAplicacoes = _aplicacaoService.RecuperaNovasAplicacoes(model.Id);
                NovasAplicacoes.ForEach(q => model.PerfilAplicacao.Add(new PerfilAplicacaoViewModel() { Inserir = false, Alterar = false, Pesquisar = false, Excluir = false, Visualizar = false, Aplicacao = q.Descricao, IdAplicacao = q.Id }));
            }
            else
            {
                var Apps = _aplicacaoService.All();

                Apps.ToList().ForEach(q => model.PerfilAplicacao.Add(new PerfilAplicacaoViewModel() { Inserir = false, Alterar = false, Pesquisar = false, Excluir = false, Visualizar = false, Aplicacao = q.Descricao, IdAplicacao = q.Id }));
            }

            return View(model);
        }

        [HttpPost]
        public ActionResult Salvar(FormCollection collection, ViewDB model)
        {
            try
            {
                string msg = Messages.MN0003;
                var obj = new TipoDB();

                #region [ VALIDAÇÃO ]

                if (!ModelState.IsValid)
                {
                    throw new AlertException(Errors(ModelState));
                }

                #endregion

                if (model.Id > 0)
                {
                    obj = _perfilService.Get(model.Id);

                    HelperMVC.LoadObject(obj, collection);
                    PreparaGrid(obj, model);

                    obj.Ativo = model.Ativo;

                    _perfilService.Update(obj);
                    msg = Messages.MN0004;
                }
                else
                {
                    obj = (TipoDB)model;
                    _perfilService.Add(obj);
                }

                return MessageBox.ShowMessage(msg, MessageBox.MessageType.Success, Url.Action("Index"));
            }
            catch (Exception ex)
            {
                return MessageBox.ShowMessage(ex);
            }
        }

        [HttpPost]
        public ActionResult AlterarStatus(long id, int page, ViewDB model = null)
        {
            try
            {
                var obj = _perfilService.Get(id);

                obj.Ativo = !obj.Ativo;

                _perfilService.Update(obj);

                return Filtro(page, model);

            }
            catch (Exception ex)
            {
                return MessageBox.ShowMessage(ex);
            }
        }

    }
}