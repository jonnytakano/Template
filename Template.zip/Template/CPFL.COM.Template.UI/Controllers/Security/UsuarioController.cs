﻿using CPFL.COM.Template.Common;
using CPFL.COM.Template.Service.Interfaces;
using PagedList;
using System;
using System.Web.Mvc;
using TipoDB = CPFL.COM.Template.Domain.Entities.Usuario;
using ViewDB = CPFL.COM.Template.Domain.ViewModel.UsuarioViewModel;

namespace CPFL.COM.Template.UI.Controllers.Security
{
    public class UsuarioController : MasterController
    {
        #region [  Initializers  ]

        private IUsuarioService _usuarioService;
        private IPerfilService _perfilService;

        public UsuarioController(IUsuarioService usuarioService, IPerfilService perfilService)
        {
            _usuarioService = usuarioService;
            _perfilService = perfilService;
        }

        protected override string TituloPagina { get { return "Usuários"; } }

        #endregion

        #region [  Internal Actions  ]

        [OutputCache(NoStore = true, Duration = 0)]
        public ActionResult AddCadastro(FormCollection collection, ViewDB model = null)
        {
            try
            {
                if (model == null) { model = new ViewDB(); }

                TipoDB obj = _usuarioService.InformacoesUsuario(model.Matricula);
                if (obj != null && !string.IsNullOrEmpty(model.Matricula))
                {
                    model = (ViewDB)obj;
                    model._Pesquisado = true;
                }
                else
                {
                    return MessageBox.ShowMessage(MessageBox.MessageType.Warning, Messages.MN0046, false);
                }

                model.PerfilItens = _perfilService.ListItens();
            }
            catch (Exception ex)
            {
                return MessageBox.ShowMessage(ex);
            }

            return View("_cadastro", model);
        }


        #endregion

        public ActionResult Index()
        {
            ViewBag.TituloPagina = TituloPagina;
            return View();
        }

        [HttpPost]
        public ActionResult Filtro(int page = 1, ViewDB model = null)
        {
            try
            {
                var dados = _usuarioService.Filter(model, page);
                return View("_Filtro", dados.ToPagedList(page, Const.RecordCountPerPage));
            }
            catch (Exception ex)
            {
                return MessageBox.ShowMessage(ex);
            }
        }

        public ActionResult Cadastro(long id = 0, ViewDB model = null)
        {
            if (model == null) { model = new ViewDB(); }

            ViewBag.TituloPagina = TituloPagina;
            ViewBag.SubmitMsg = Messages.MA0002;

            if (id > 0)
            {
                ViewBag.SubmitMsg = Messages.MA0003;
                model = (ViewDB)_usuarioService.Get(id);
                model._Pesquisado = true;
            }

            model.PerfilItens = _perfilService.ListItens();

            return View(model);
        }
               
        [HttpPost]
        public ActionResult Salvar(FormCollection collection, ViewDB model)
        {
            try
            {
                string msg = Messages.MN0003;
                var obj = new TipoDB();

                #region [ VALIDAÇÃO ]

                if (!ModelState.IsValid)
                {
                    throw new AlertException(Errors(ModelState));
                }

                #endregion

                if (model.Id > 0)
                {
                    obj = _usuarioService.Get(model.Id);

                    HelperMVC.LoadObject(obj, collection);
                    obj.Ativo = model.Ativo;

                    _usuarioService.Update(obj);
                    msg = Messages.MN0004;
                }
                else
                {
                    obj = (TipoDB)model;
                    HelperMVC.LoadObject(obj, collection);
                    _usuarioService.Add(obj);
                }

                return MessageBox.ShowMessage(msg, MessageBox.MessageType.Success, Url.Action("Index"));
            }
            catch (Exception ex)
            {
                return MessageBox.ShowMessage(ex);
            }
        }

        [HttpPost]
        public ActionResult AlterarStatus(long id, int page, ViewDB model = null)
        {
            try
            {
                var obj = _usuarioService.Get(id);

                obj.Ativo = !obj.Ativo;

                _usuarioService.Update(obj);

                return Filtro(page, model);
            }
            catch (Exception ex)
            {
                return MessageBox.ShowMessage(ex);
            }
        }
    }
}